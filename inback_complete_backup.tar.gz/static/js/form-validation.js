// Frontend form validation system
(function() {
    'use strict';

    // Validation patterns
    const patterns = {
        name: /^[a-zA-Zа-яА-ЯёЁ\s]{2,50}$/,
        phone: /^(\+7|8)?[\s\-]?\(?9\d{2}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    };

    // Error messages
    const messages = {
        name: 'Введите корректное имя (только буквы, 2-50 символов)',
        phone: 'Введите корректный номер телефона (например: +7 900 123-45-67)',
        email: 'Введите корректный email адрес',
        required: 'Это поле обязательно для заполнения'
    };

    // Phone number formatting
    function formatPhoneNumber(input) {
        let value = input.value.replace(/\D/g, '');
        
        if (value.length === 0) return;
        
        if (value[0] === '8') value = '7' + value.slice(1);
        if (value[0] !== '7') value = '7' + value;
        
        if (value.length > 11) value = value.slice(0, 11);
        
        let formatted = '+7';
        if (value.length > 1) formatted += ' (' + value.slice(1, 4);
        if (value.length > 4) formatted += ') ' + value.slice(4, 7);
        if (value.length > 7) formatted += '-' + value.slice(7, 9);
        if (value.length > 9) formatted += '-' + value.slice(9, 11);
        
        input.value = formatted;
    }

    // Real-time validation
    function validateField(field) {
        const fieldType = field.dataset.validate;
        const value = field.value.trim();
        const isRequired = field.required || field.dataset.required === 'true';
        
        // Remove previous error styling
        field.classList.remove('error', 'success');
        removeErrorMessage(field);
        
        // Check if required field is empty
        if (isRequired && !value) {
            showError(field, messages.required);
            return false;
        }
        
        // Skip validation for empty optional fields
        if (!value && !isRequired) {
            return true;
        }
        
        // Validate based on type
        let isValid = true;
        let errorMessage = '';
        
        switch (fieldType) {
            case 'name':
                isValid = patterns.name.test(value);
                errorMessage = messages.name;
                break;
            case 'phone':
                const cleanPhone = value.replace(/\D/g, '');
                isValid = cleanPhone.length >= 10 && patterns.phone.test(value);
                errorMessage = messages.phone;
                break;
            case 'email':
                isValid = patterns.email.test(value);
                errorMessage = messages.email;
                break;
        }
        
        if (!isValid) {
            showError(field, errorMessage);
            return false;
        } else {
            field.classList.add('success');
            return true;
        }
    }

    // Show error message
    function showError(field, message) {
        field.classList.add('error');
        
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }

    // Remove error message
    function removeErrorMessage(field) {
        const errorMessage = field.parentNode.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    // Validate entire form
    function validateForm(form) {
        const fields = form.querySelectorAll('[data-validate]');
        let isValid = true;
        
        fields.forEach(field => {
            if (!validateField(field)) {
                isValid = false;
            }
        });
        
        return isValid;
    }

    // Initialize validation for all forms
    function initFormValidation() {
        const forms = document.querySelectorAll('form[data-validation="true"]');
        
        forms.forEach(form => {
            const fields = form.querySelectorAll('[data-validate]');
            
            // Add real-time validation to fields
            fields.forEach(field => {
                // Phone number formatting
                if (field.dataset.validate === 'phone') {
                    field.addEventListener('input', () => formatPhoneNumber(field));
                }
                
                // Validation on blur
                field.addEventListener('blur', () => validateField(field));
                
                // Clear error on focus
                field.addEventListener('focus', () => {
                    field.classList.remove('error');
                    removeErrorMessage(field);
                });
            });
            
            // Form submission validation
            form.addEventListener('submit', (e) => {
                if (!validateForm(form)) {
                    e.preventDefault();
                    
                    // Focus first invalid field
                    const firstError = form.querySelector('.error');
                    if (firstError) {
                        firstError.focus();
                        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                    
                    return false;
                }
            });
        });
    }

    // Add validation CSS styles
    function addValidationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .form-field.error {
                border-color: #ef4444 !important;
                box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            }
            
            .form-field.success {
                border-color: #10b981 !important;
                box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
            }
            
            .error-message {
                color: #ef4444;
                font-size: 0.875rem;
                margin-top: 0.25rem;
                display: block;
                animation: fadeIn 0.3s ease;
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-4px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .form-field:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
        `;
        document.head.appendChild(style);
    }

    // Initialize when DOM is ready
    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
            return;
        }
        
        addValidationStyles();
        initFormValidation();
        
        console.log('Form validation initialized');
    }
    
    init();
})();