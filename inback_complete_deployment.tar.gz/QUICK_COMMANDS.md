# InBack - Быстрые команды для развертывания

## 🚀 Команды для быстрой настройки в Replit

### 1. Восстановление базы данных (выполнить в Shell)
```bash
# Восстановить полную базу данных
psql $DATABASE_URL < database_dump.sql

# Проверить количество сохраненных поисков (должно быть 27)
psql $DATABASE_URL -c "SELECT COUNT(*) FROM saved_searches;"

# Проверить текущий счетчик автоинкремента (должен быть 28)
psql $DATABASE_URL -c "SELECT last_value FROM saved_searches_id_seq;"
```

### 2. Создание админских аккаунтов
```bash
# Создать/сбросить пароль менеджера
python reset_stanislaw_password.py

# Альтернативно - создать данные вручную
python populate_simple.py
```

### 3. Проверка работоспособности
```bash
# Проверить структуру базы
psql $DATABASE_URL -c "\dt"

# Проверить количество объектов недвижимости  
psql $DATABASE_URL -c "SELECT COUNT(*) FROM properties;"

# Проверить пользователей
psql $DATABASE_URL -c "SELECT email, created_at FROM users;"

# Проверить менеджеров
psql $DATABASE_URL -c "SELECT email, name FROM managers;"
```

### 4. Тестирование функций (через Python console)
```python
# Тест подключения к базе
from app import db
print("Database connected:", db.engine.execute("SELECT 1").scalar())

# Тест сохраненных поисков  
from models import ManagerSavedSearch
searches = ManagerSavedSearch.query.all()
print(f"Saved searches: {len(searches)}")

# Тест создания нового поиска (должно работать без ошибок)
from models import SavedSearch, db
from datetime import datetime
test_search = SavedSearch(
    user_id=1,
    name="Тестовый поиск", 
    search_type="properties"
)
db.session.add(test_search)
db.session.commit()
print(f"New search ID: {test_search.id}")
```

## 🔍 Диагностика проблем

### Если ошибка "duplicate key value violates unique constraint"
```bash
# Исправить счетчик автоинкремента
psql $DATABASE_URL -c "SELECT setval('saved_searches_id_seq', (SELECT MAX(id) FROM saved_searches));"
```

### Если ошибка "saved_search_id is invalid keyword"
```bash
# Проверить что используется правильная версия app.py
grep -n "saved_search_id" app.py
# Не должно быть результатов в коде создания SentSearch
```

### Если не работают статические файлы
```bash
# Проверить структуру папок
ls -la static/
ls -la templates/
ls -la css/
ls -la js/
```

## 📋 Чек-лист успешного развертывания

- [ ] PostgreSQL создана в Replit
- [ ] Файл `database_dump.sql` восстановлен  
- [ ] Переменная `SESSION_SECRET` установлена
- [ ] Приложение запущено без ошибок
- [ ] Главная страница открывается
- [ ] Менеджерский вход работает (`/manager/login`)
- [ ] 27 сохраненных поисков видны в панели менеджера
- [ ] Отправка поиска клиенту работает без ошибок
- [ ] Личный кабинет покупателя открывается в новом дизайне
- [ ] Система избранного функционирует

## 🎯 Готовые тестовые данные

### Менеджеры
- `manager@inback.ru` - основной менеджер (Станислав)

### Покупатели  
- `demo@inback.ru` - демо пользователь
- `user@example.com` - тестовый пользователь
- И еще 14+ созданных аккаунтов

### Данные недвижимости
- 195+ объектов с полными характеристиками
- 30+ жилых комплексов Краснодара
- Реальные адреса и координаты
- Рассчитанные цены с кэшбеком

### Сохраненные поиски (27 штук)
- Различные типы поисков (1-комн, 2-комн, студии)
- Поиски по районам Краснодара  
- Поиски по бюджету и площади
- Готовы к отправке клиентам

---
**Среднее время настройки:** 3-5 минут при следовании инструкции