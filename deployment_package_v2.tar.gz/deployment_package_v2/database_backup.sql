--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    full_name character varying(100) NOT NULL,
    admin_id character varying(20) NOT NULL,
    role character varying(50),
    permissions text,
    is_active boolean,
    is_super_admin boolean,
    profile_image character varying(200),
    phone character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_login timestamp without time zone
);


ALTER TABLE public.admins OWNER TO neondb_owner;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admins_id_seq OWNER TO neondb_owner;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: applications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.applications (
    id integer NOT NULL,
    user_id integer,
    contact_name character varying(200),
    contact_email character varying(120),
    contact_phone character varying(20),
    property_id character varying(50),
    property_name character varying(200) NOT NULL,
    complex_name character varying(200) NOT NULL,
    status character varying(20),
    message text,
    preferred_contact character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.applications OWNER TO neondb_owner;

--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.applications_id_seq OWNER TO neondb_owner;

--
-- Name: applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.applications_id_seq OWNED BY public.applications.id;


--
-- Name: blog_article_tags; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_article_tags (
    article_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.blog_article_tags OWNER TO neondb_owner;

--
-- Name: blog_articles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_articles (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    excerpt character varying(500),
    content text NOT NULL,
    author_id integer NOT NULL,
    author_name character varying(100),
    category_id integer NOT NULL,
    status character varying(20),
    published_at timestamp without time zone,
    scheduled_at timestamp without time zone,
    meta_title character varying(200),
    meta_description character varying(300),
    meta_keywords character varying(500),
    featured_image character varying(300),
    featured_image_alt character varying(200),
    is_featured boolean,
    allow_comments boolean,
    views_count integer,
    reading_time integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_articles OWNER TO neondb_owner;

--
-- Name: blog_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_articles_id_seq OWNER TO neondb_owner;

--
-- Name: blog_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_articles_id_seq OWNED BY public.blog_articles.id;


--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    color character varying(20),
    icon character varying(50),
    meta_title character varying(200),
    meta_description character varying(300),
    sort_order integer,
    is_active boolean,
    articles_count integer,
    views_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_categories OWNER TO neondb_owner;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_categories_id_seq OWNER TO neondb_owner;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_comments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_comments (
    id integer NOT NULL,
    article_id integer NOT NULL,
    author_name character varying(100) NOT NULL,
    author_email character varying(120) NOT NULL,
    author_website character varying(200),
    user_id integer,
    content text NOT NULL,
    status character varying(20),
    ip_address character varying(50),
    user_agent character varying(300),
    parent_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_comments OWNER TO neondb_owner;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_comments_id_seq OWNER TO neondb_owner;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_comments_id_seq OWNED BY public.blog_comments.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    excerpt text,
    meta_title character varying(255),
    meta_description text,
    meta_keywords character varying(500),
    status character varying(20),
    featured_image character varying(500),
    category character varying(100),
    tags text,
    author_id integer NOT NULL,
    published_at timestamp without time zone,
    scheduled_for timestamp without time zone,
    views_count integer,
    likes_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_posts OWNER TO neondb_owner;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_id_seq OWNER TO neondb_owner;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: blog_tags; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.blog_tags (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    usage_count integer,
    created_at timestamp without time zone
);


ALTER TABLE public.blog_tags OWNER TO neondb_owner;

--
-- Name: blog_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.blog_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_tags_id_seq OWNER TO neondb_owner;

--
-- Name: blog_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.blog_tags_id_seq OWNED BY public.blog_tags.id;


--
-- Name: callback_requests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.callback_requests (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(120),
    preferred_time character varying(50),
    notes text,
    interest character varying(100),
    budget character varying(50),
    timing character varying(50),
    status character varying(50),
    assigned_manager_id integer,
    manager_notes text,
    created_at timestamp without time zone,
    processed_at timestamp without time zone
);


ALTER TABLE public.callback_requests OWNER TO neondb_owner;

--
-- Name: callback_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.callback_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.callback_requests_id_seq OWNER TO neondb_owner;

--
-- Name: callback_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.callback_requests_id_seq OWNED BY public.callback_requests.id;


--
-- Name: cashback_applications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cashback_applications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id character varying(50),
    property_name character varying(200) NOT NULL,
    property_type character varying(50) NOT NULL,
    property_size double precision NOT NULL,
    property_price integer NOT NULL,
    complex_name character varying(200) NOT NULL,
    developer_name character varying(200) NOT NULL,
    cashback_amount integer NOT NULL,
    cashback_percent double precision NOT NULL,
    status character varying(50),
    application_date timestamp without time zone,
    approved_date timestamp without time zone,
    payout_date timestamp without time zone,
    notes text,
    approved_by_manager_id integer,
    manager_notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cashback_applications OWNER TO neondb_owner;

--
-- Name: cashback_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cashback_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cashback_applications_id_seq OWNER TO neondb_owner;

--
-- Name: cashback_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cashback_applications_id_seq OWNED BY public.cashback_applications.id;


--
-- Name: cashback_payouts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cashback_payouts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount numeric(15,2) NOT NULL,
    status character varying(50),
    payment_method character varying(100),
    admin_notes text,
    requested_at timestamp without time zone,
    processed_at timestamp without time zone
);


ALTER TABLE public.cashback_payouts OWNER TO neondb_owner;

--
-- Name: cashback_payouts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cashback_payouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cashback_payouts_id_seq OWNER TO neondb_owner;

--
-- Name: cashback_payouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cashback_payouts_id_seq OWNED BY public.cashback_payouts.id;


--
-- Name: cashback_records; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cashback_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id integer,
    property_name character varying(200) NOT NULL,
    property_price double precision NOT NULL,
    amount double precision NOT NULL,
    percentage double precision NOT NULL,
    status character varying(20),
    created_at timestamp without time zone,
    approved_at timestamp without time zone,
    paid_at timestamp without time zone
);


ALTER TABLE public.cashback_records OWNER TO neondb_owner;

--
-- Name: cashback_records_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cashback_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cashback_records_id_seq OWNER TO neondb_owner;

--
-- Name: cashback_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cashback_records_id_seq OWNED BY public.cashback_records.id;


--
-- Name: cities; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cities (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    is_active boolean,
    is_default boolean,
    phone character varying(20),
    email character varying(120),
    address character varying(200),
    latitude double precision,
    longitude double precision,
    zoom_level integer,
    description text,
    meta_title character varying(200),
    meta_description character varying(300),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cities OWNER TO neondb_owner;

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cities_id_seq OWNER TO neondb_owner;

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cities_id_seq OWNED BY public.cities.id;


--
-- Name: client_property_recommendations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.client_property_recommendations (
    id integer NOT NULL,
    manager_id integer NOT NULL,
    client_id integer NOT NULL,
    search_id integer NOT NULL,
    message text,
    sent_at timestamp without time zone,
    viewed_at timestamp without time zone
);


ALTER TABLE public.client_property_recommendations OWNER TO neondb_owner;

--
-- Name: client_property_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.client_property_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_property_recommendations_id_seq OWNER TO neondb_owner;

--
-- Name: client_property_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.client_property_recommendations_id_seq OWNED BY public.client_property_recommendations.id;


--
-- Name: collection_properties; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.collection_properties (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    property_id character varying(100) NOT NULL,
    property_name character varying(255),
    property_price integer,
    complex_name character varying(255),
    property_type character varying(100),
    property_size double precision,
    manager_note text,
    order_index integer,
    created_at timestamp without time zone
);


ALTER TABLE public.collection_properties OWNER TO neondb_owner;

--
-- Name: collection_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.collection_properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collection_properties_id_seq OWNER TO neondb_owner;

--
-- Name: collection_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.collection_properties_id_seq OWNED BY public.collection_properties.id;


--
-- Name: collections; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.collections (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    created_by_manager_id integer NOT NULL,
    assigned_to_user_id integer,
    status character varying(50),
    is_public boolean,
    tags text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sent_at timestamp without time zone,
    viewed_at timestamp without time zone
);


ALTER TABLE public.collections OWNER TO neondb_owner;

--
-- Name: collections_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collections_id_seq OWNER TO neondb_owner;

--
-- Name: collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.collections_id_seq OWNED BY public.collections.id;


--
-- Name: developer_appointments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.developer_appointments (
    id integer NOT NULL,
    user_id integer,
    property_id character varying(50),
    developer_name character varying(200) NOT NULL,
    complex_name character varying(200) NOT NULL,
    appointment_date timestamp without time zone NOT NULL,
    appointment_time character varying(10) NOT NULL,
    status character varying(50),
    client_name character varying(200) NOT NULL,
    client_phone character varying(20) NOT NULL,
    notes text,
    created_at timestamp without time zone,
    developer_id integer
);


ALTER TABLE public.developer_appointments OWNER TO neondb_owner;

--
-- Name: developer_appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.developer_appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.developer_appointments_id_seq OWNER TO neondb_owner;

--
-- Name: developer_appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.developer_appointments_id_seq OWNED BY public.developer_appointments.id;


--
-- Name: developers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.developers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    full_name character varying(300),
    established_year integer,
    description text,
    logo_url character varying(300),
    phone character varying(20),
    email character varying(120),
    website character varying(200),
    address character varying(300),
    latitude double precision,
    longitude double precision,
    zoom_level integer DEFAULT 13,
    total_complexes integer DEFAULT 0,
    total_properties integer DEFAULT 0,
    properties_sold integer DEFAULT 0,
    rating double precision DEFAULT 4.8,
    experience_years integer DEFAULT 10,
    min_price integer,
    max_cashback_percent double precision DEFAULT 10.0,
    inn character varying(20),
    kpp character varying(20),
    ogrn character varying(20),
    legal_address character varying(300),
    bank_name character varying(200),
    bank_bik character varying(20),
    bank_account character varying(30),
    features text,
    infrastructure text,
    is_active boolean DEFAULT true,
    is_partner boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.developers OWNER TO neondb_owner;

--
-- Name: developers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.developers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.developers_id_seq OWNER TO neondb_owner;

--
-- Name: developers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.developers_id_seq OWNED BY public.developers.id;


--
-- Name: districts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.districts (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.districts OWNER TO neondb_owner;

--
-- Name: districts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.districts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.districts_id_seq OWNER TO neondb_owner;

--
-- Name: districts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.districts_id_seq OWNED BY public.districts.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    user_id integer NOT NULL,
    filename character varying(200) NOT NULL,
    original_filename character varying(200) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer NOT NULL,
    file_path character varying(500) NOT NULL,
    document_type character varying(100),
    status character varying(50),
    reviewed_at timestamp without time zone,
    reviewer_notes text,
    reviewed_by_manager_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.documents OWNER TO neondb_owner;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO neondb_owner;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: favorite_properties; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.favorite_properties (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id character varying(50),
    property_name character varying(200) NOT NULL,
    property_type character varying(50),
    property_size double precision,
    property_price integer,
    complex_name character varying(200),
    developer_name character varying(200),
    property_image character varying(500),
    property_url character varying(500),
    cashback_amount integer,
    cashback_percent double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.favorite_properties OWNER TO neondb_owner;

--
-- Name: favorite_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.favorite_properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorite_properties_id_seq OWNER TO neondb_owner;

--
-- Name: favorite_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.favorite_properties_id_seq OWNED BY public.favorite_properties.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    property_id integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.favorites OWNER TO neondb_owner;

--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorites_id_seq OWNER TO neondb_owner;

--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: manager_saved_searches; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.manager_saved_searches (
    id integer NOT NULL,
    manager_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    search_type character varying(20),
    location character varying(200),
    property_type character varying(50),
    price_min integer,
    price_max integer,
    size_min double precision,
    size_max double precision,
    developer character varying(200),
    complex_name character varying(200),
    floor_min integer,
    floor_max integer,
    cashback_min integer,
    additional_filters text,
    is_template boolean,
    usage_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_used timestamp without time zone
);


ALTER TABLE public.manager_saved_searches OWNER TO neondb_owner;

--
-- Name: manager_saved_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.manager_saved_searches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manager_saved_searches_id_seq OWNER TO neondb_owner;

--
-- Name: manager_saved_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.manager_saved_searches_id_seq OWNED BY public.manager_saved_searches.id;


--
-- Name: managers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.managers (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    password_hash character varying(256) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone character varying(20),
    "position" character varying(50),
    can_approve_cashback boolean,
    can_manage_documents boolean,
    can_create_collections boolean,
    max_cashback_approval integer,
    is_active boolean,
    profile_image character varying(200),
    manager_id character varying(20) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_login timestamp without time zone
);


ALTER TABLE public.managers OWNER TO neondb_owner;

--
-- Name: managers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.managers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.managers_id_seq OWNER TO neondb_owner;

--
-- Name: managers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.managers_id_seq OWNED BY public.managers.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    type character varying(50),
    icon character varying(50),
    is_read boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.notifications OWNER TO neondb_owner;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO neondb_owner;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: recommendation_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recommendation_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    manager_id integer NOT NULL,
    client_id integer NOT NULL,
    color character varying(20),
    is_active boolean,
    recommendations_count integer,
    last_used timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.recommendation_categories OWNER TO neondb_owner;

--
-- Name: recommendation_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recommendation_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommendation_categories_id_seq OWNER TO neondb_owner;

--
-- Name: recommendation_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recommendation_categories_id_seq OWNED BY public.recommendation_categories.id;


--
-- Name: recommendation_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recommendation_templates (
    id integer NOT NULL,
    manager_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    recommendation_type character varying(20) NOT NULL,
    default_title character varying(255),
    default_description text,
    default_notes text,
    default_highlighted_features text,
    default_priority character varying(20),
    is_active boolean,
    usage_count integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_used timestamp without time zone
);


ALTER TABLE public.recommendation_templates OWNER TO neondb_owner;

--
-- Name: recommendation_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recommendation_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommendation_templates_id_seq OWNER TO neondb_owner;

--
-- Name: recommendation_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recommendation_templates_id_seq OWNED BY public.recommendation_templates.id;


--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.recommendations (
    id integer NOT NULL,
    manager_id integer NOT NULL,
    client_id integer NOT NULL,
    category_id integer,
    title character varying(255) NOT NULL,
    description text,
    recommendation_type character varying(20) NOT NULL,
    item_id character varying(100) NOT NULL,
    item_name character varying(255) NOT NULL,
    item_data text,
    manager_notes text,
    highlighted_features text,
    priority_level character varying(20),
    status character varying(20),
    viewed_at timestamp without time zone,
    responded_at timestamp without time zone,
    client_response character varying(20),
    client_notes text,
    viewing_requested boolean,
    viewing_scheduled_at timestamp without time zone,
    created_at timestamp without time zone,
    sent_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.recommendations OWNER TO neondb_owner;

--
-- Name: recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommendations_id_seq OWNER TO neondb_owner;

--
-- Name: recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.recommendations_id_seq OWNED BY public.recommendations.id;


--
-- Name: residential_complexes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.residential_complexes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    district_id integer,
    developer_id integer,
    cashback_rate numeric(5,2) DEFAULT 5.0
);


ALTER TABLE public.residential_complexes OWNER TO neondb_owner;

--
-- Name: residential_complexes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.residential_complexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.residential_complexes_id_seq OWNER TO neondb_owner;

--
-- Name: residential_complexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.residential_complexes_id_seq OWNED BY public.residential_complexes.id;


--
-- Name: room_types; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.room_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    rooms_count integer
);


ALTER TABLE public.room_types OWNER TO neondb_owner;

--
-- Name: room_types_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.room_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_types_id_seq OWNER TO neondb_owner;

--
-- Name: room_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.room_types_id_seq OWNED BY public.room_types.id;


--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.saved_searches (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    search_type character varying(20),
    location character varying(200),
    property_type character varying(50),
    price_min integer,
    price_max integer,
    size_min double precision,
    size_max double precision,
    developer character varying(200),
    complex_name character varying(200),
    floor_min integer,
    floor_max integer,
    cashback_min integer,
    additional_filters text,
    notify_new_matches boolean,
    last_notification_sent timestamp without time zone,
    created_from_quiz boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_used timestamp without time zone
);


ALTER TABLE public.saved_searches OWNER TO neondb_owner;

--
-- Name: saved_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.saved_searches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.saved_searches_id_seq OWNER TO neondb_owner;

--
-- Name: saved_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.saved_searches_id_seq OWNED BY public.saved_searches.id;


--
-- Name: search_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.search_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    category_type character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.search_categories OWNER TO neondb_owner;

--
-- Name: search_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.search_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_categories_id_seq OWNER TO neondb_owner;

--
-- Name: search_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.search_categories_id_seq OWNED BY public.search_categories.id;


--
-- Name: sent_searches; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sent_searches (
    id integer NOT NULL,
    manager_id integer NOT NULL,
    client_id integer NOT NULL,
    manager_search_id integer,
    name character varying(100) NOT NULL,
    description text,
    additional_filters text,
    status character varying(20),
    viewed_at timestamp without time zone,
    applied_at timestamp without time zone,
    expires_at timestamp without time zone,
    sent_at timestamp without time zone
);


ALTER TABLE public.sent_searches OWNER TO neondb_owner;

--
-- Name: sent_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sent_searches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sent_searches_id_seq OWNER TO neondb_owner;

--
-- Name: sent_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sent_searches_id_seq OWNED BY public.sent_searches.id;


--
-- Name: streets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.streets (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    district_id integer
);


ALTER TABLE public.streets OWNER TO neondb_owner;

--
-- Name: streets_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.streets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.streets_id_seq OWNER TO neondb_owner;

--
-- Name: streets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.streets_id_seq OWNED BY public.streets.id;


--
-- Name: user_notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    notification_type character varying(50),
    icon character varying(50),
    is_read boolean,
    action_url character varying(500),
    created_at timestamp without time zone,
    read_at timestamp without time zone
);


ALTER TABLE public.user_notifications OWNER TO neondb_owner;

--
-- Name: user_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_notifications_id_seq OWNER TO neondb_owner;

--
-- Name: user_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_notifications_id_seq OWNED BY public.user_notifications.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    phone character varying(20),
    telegram_id character varying(50),
    full_name character varying(100) NOT NULL,
    password_hash character varying(256),
    temp_password_hash character varying(256),
    created_by_admin boolean,
    preferred_contact character varying(20),
    email_notifications boolean,
    telegram_notifications boolean,
    notify_recommendations boolean,
    notify_saved_searches boolean,
    notify_applications boolean,
    notify_cashback boolean,
    notify_marketing boolean,
    profile_image character varying(200),
    user_id character varying(20) NOT NULL,
    role character varying(20),
    is_active boolean,
    is_verified boolean,
    verification_token character varying(100),
    is_demo boolean,
    verified boolean,
    registration_source character varying(50),
    client_notes text,
    assigned_manager_id integer,
    client_status character varying(50),
    preferred_district character varying(100),
    property_type character varying(50),
    room_count character varying(20),
    budget_range character varying(50),
    quiz_completed boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_login timestamp without time zone
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: applications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.applications ALTER COLUMN id SET DEFAULT nextval('public.applications_id_seq'::regclass);


--
-- Name: blog_articles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_articles ALTER COLUMN id SET DEFAULT nextval('public.blog_articles_id_seq'::regclass);


--
-- Name: blog_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: blog_comments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_comments ALTER COLUMN id SET DEFAULT nextval('public.blog_comments_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: blog_tags id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_tags ALTER COLUMN id SET DEFAULT nextval('public.blog_tags_id_seq'::regclass);


--
-- Name: callback_requests id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.callback_requests ALTER COLUMN id SET DEFAULT nextval('public.callback_requests_id_seq'::regclass);


--
-- Name: cashback_applications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_applications ALTER COLUMN id SET DEFAULT nextval('public.cashback_applications_id_seq'::regclass);


--
-- Name: cashback_payouts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_payouts ALTER COLUMN id SET DEFAULT nextval('public.cashback_payouts_id_seq'::regclass);


--
-- Name: cashback_records id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_records ALTER COLUMN id SET DEFAULT nextval('public.cashback_records_id_seq'::regclass);


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_id_seq'::regclass);


--
-- Name: client_property_recommendations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_property_recommendations ALTER COLUMN id SET DEFAULT nextval('public.client_property_recommendations_id_seq'::regclass);


--
-- Name: collection_properties id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collection_properties ALTER COLUMN id SET DEFAULT nextval('public.collection_properties_id_seq'::regclass);


--
-- Name: collections id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collections ALTER COLUMN id SET DEFAULT nextval('public.collections_id_seq'::regclass);


--
-- Name: developer_appointments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developer_appointments ALTER COLUMN id SET DEFAULT nextval('public.developer_appointments_id_seq'::regclass);


--
-- Name: developers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developers ALTER COLUMN id SET DEFAULT nextval('public.developers_id_seq'::regclass);


--
-- Name: districts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.districts ALTER COLUMN id SET DEFAULT nextval('public.districts_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: favorite_properties id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorite_properties ALTER COLUMN id SET DEFAULT nextval('public.favorite_properties_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: manager_saved_searches id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.manager_saved_searches ALTER COLUMN id SET DEFAULT nextval('public.manager_saved_searches_id_seq'::regclass);


--
-- Name: managers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.managers ALTER COLUMN id SET DEFAULT nextval('public.managers_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: recommendation_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_categories ALTER COLUMN id SET DEFAULT nextval('public.recommendation_categories_id_seq'::regclass);


--
-- Name: recommendation_templates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_templates ALTER COLUMN id SET DEFAULT nextval('public.recommendation_templates_id_seq'::regclass);


--
-- Name: recommendations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendations ALTER COLUMN id SET DEFAULT nextval('public.recommendations_id_seq'::regclass);


--
-- Name: residential_complexes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.residential_complexes ALTER COLUMN id SET DEFAULT nextval('public.residential_complexes_id_seq'::regclass);


--
-- Name: room_types id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.room_types ALTER COLUMN id SET DEFAULT nextval('public.room_types_id_seq'::regclass);


--
-- Name: saved_searches id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.saved_searches ALTER COLUMN id SET DEFAULT nextval('public.saved_searches_id_seq'::regclass);


--
-- Name: search_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.search_categories ALTER COLUMN id SET DEFAULT nextval('public.search_categories_id_seq'::regclass);


--
-- Name: sent_searches id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sent_searches ALTER COLUMN id SET DEFAULT nextval('public.sent_searches_id_seq'::regclass);


--
-- Name: streets id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.streets ALTER COLUMN id SET DEFAULT nextval('public.streets_id_seq'::regclass);


--
-- Name: user_notifications id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_notifications ALTER COLUMN id SET DEFAULT nextval('public.user_notifications_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.admins (id, email, password_hash, full_name, admin_id, role, permissions, is_active, is_super_admin, profile_image, phone, created_at, updated_at, last_login) FROM stdin;
1	admin@inback.ru	scrypt:32768:8:1$JVCqHauCtXuI7no4$1ce6e42a1cbda23c0dda818f5df6247c3208931ffa0221ee645f5084daa99a591db021681cdb348c5d07386c3f9f77bbe6f97471efe5996c87fc60b6b12b2d0d	Главный Администратор	ADM89406111	super_admin	{"all": true}	t	f	https://randomuser.me/api/portraits/men/1.jpg	\N	2025-08-12 19:11:43.594249	2025-08-14 11:07:23.913457	2025-08-14 11:07:23.912178
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.applications (id, user_id, contact_name, contact_email, contact_phone, property_id, property_name, complex_name, status, message, preferred_contact, created_at, updated_at) FROM stdin;
5	\N	Тестов	demo@inback.ru	+7 (952) 490-82-69	\N	Подбор квартиры	По предпочтениям	new	Заявка на подбор квартиры:\nИмя: Тестов\nEmail: demo@inback.ru\nТелефон: +7 (952) 490-82-69\nРайон: Центральный\nТип: Квартира\nКомнат: 2\nБюджет: До 3 млн	email	2025-08-13 18:49:44.536632	2025-08-13 18:49:44.536635
\.


--
-- Data for Name: blog_article_tags; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_article_tags (article_id, tag_id) FROM stdin;
\.


--
-- Data for Name: blog_articles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_articles (id, title, slug, excerpt, content, author_id, author_name, category_id, status, published_at, scheduled_at, meta_title, meta_description, meta_keywords, featured_image, featured_image_alt, is_featured, allow_comments, views_count, reading_time, created_at, updated_at) FROM stdin;
1	Тестовая	тестовая	<p>тестовая</p>	<h1>Тестовая<br><br></h1>\n<p>тестовая<br><em>тествоая</em></p>	1	Автор	7	published	2025-08-12 22:25:50	\N	тестовая	тестовая	тестовая			f	t	0	1	2025-08-12 22:25:50	2025-08-12 22:25:50
2	район	район	<p>район</p>	<h1>Район<br><br><br><br><br></h1>\n<p>район</p>	1	Автор	2	published	2025-08-12 22:37:36	\N	район 	район 	район			t	t	0	1	2025-08-12 22:37:36	2025-08-12 22:37:36
\.


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_categories (id, name, slug, description, color, icon, meta_title, meta_description, sort_order, is_active, articles_count, views_count, created_at, updated_at) FROM stdin;
1	Новости рынка	market-news	Актуальные новости рынка недвижимости	blue	fas fa-newspaper			1	t	0	0	2025-08-11 22:25:42	2025-08-12 22:42:35
2	Районы Краснодара	districts	Обзоры районов города	green	fas fa-map-marker-alt			2	t	2	0	2025-08-11 22:25:42	2025-08-12 22:42:37
3	Ипотека	mortgage	Всё об ипотечном кредитовании	purple	fas fa-home			3	t	1	0	2025-08-11 22:25:42	2025-08-12 22:42:35
4	ЖК и застройщики	developers	Обзоры жилых комплексов	red	fas fa-building			4	t	0	0	2025-08-11 22:25:42	2025-08-12 22:42:36
5	Советы покупателям	tips	Полезные советы при покупке новостроек	orange	fas fa-lightbulb			5	t	1	0	2025-08-11 22:25:42	2025-08-11 22:25:42
6	Инвестиции	investments	Статьи об инвестициях в недвижимость	yellow	fas fa-chart-line			6	t	1	0	2025-08-11 22:25:42	2025-08-12 22:42:36
7	Тест	test	Тестовая категория	gray	fas fa-folder			7	t	1	0	2025-08-11 22:25:42	2025-08-12 23:04:59
8	Новая категория	новая-категория	Описание новой категории	blue				0	t	0	0	2025-08-12 22:21:24	2025-08-12 22:21:24
9	Тестович	тестович	фыв	blue	fas fa-folder			0	t	0	0	2025-08-12 22:24:18	2025-08-12 22:24:18
10	Аналитика	аналитика	Статьи по теме Аналитика	blue				0	t	1	0	2025-08-12 22:34:28	2025-08-12 22:42:36
11	Кешбек	кешбек	Статьи по теме Кешбек	blue				0	t	1	0	2025-08-12 22:34:28	2025-08-12 23:04:57
12	Тестовая категория	тестовая-категория	Описание тестовой категории	blue				0	t	0	0	2025-08-13 00:57:49	2025-08-13 00:57:49
\.


--
-- Data for Name: blog_comments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_comments (id, article_id, author_name, author_email, author_website, user_id, content, status, ip_address, user_agent, parent_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_posts (id, title, slug, content, excerpt, meta_title, meta_description, meta_keywords, status, featured_image, category, tags, author_id, published_at, scheduled_for, views_count, likes_count, created_at, updated_at) FROM stdin;
4	Ипотечные программы 2024: льготы и условия	ipotechnye-programmy-2024-lgoty-i-usloviya	Обзор актуальных ипотечных программ 2024 года.\n\nСемейная ипотека:\n- Ставка от 5.5% годовых\n- Для семей с детьми\n- Первоначальный взнос от 20%\n\nIT-ипотека:\n- Ставка от 5.0% годовых  \n- Для IT-специалистов\n- Первоначальный взнос от 15%\n\nВоенная ипотека:\n- Льготные условия для военнослужащих\n- Государственная поддержка\n- Особые требования к объектам\n\nМатеринский капитал:\n- Можно использовать как первоначальный взнос\n- Дополнительные льготы\n- Упрощенная процедура оформления	Подробный обзор ипотечных программ и льгот, доступных в 2024 году	Ипотечные программы 2024: льготы и условия	Подробный обзор ипотечных программ и льгот, доступных в 2024 году	\N	published	/attached_assets/Screenshot_101_1754873881260.jpg	Ипотека	["ипотека", "льготы", "2024"]	1	2025-08-12 19:19:17.119603	\N	0	0	2025-08-12 19:19:17.119611	2025-08-12 19:19:52.371541
5	Инвестиции в недвижимость Краснодара: аналитика рынка	investitsii-v-nedvizhimost-krasnodara-analitika-rynka	Краснодар остается одним из наиболее привлекательных городов для инвестиций в недвижимость.\n\nКлючевые факторы роста:\n- Активное развитие инфраструктуры\n- Приток населения из других регионов\n- Развитие IT-сектора\n- Близость к морю и туристическим зонам\n\nПерспективные районы:\n1. Центральный - стабильный рост стоимости\n2. Карасунский - новые жилые комплексы\n3. Прикубанский - развитая инфраструктура\n\nРекомендации инвесторам:\n- Выбирайте объекты в перспективных локациях\n- Учитывайте транспортную доступность\n- Обращайте внимание на качество застройщика\n- Рассматривайте возможности сдачи в аренду	Анализ инвестиционной привлекательности недвижимости Краснодара	Инвестиции в недвижимость Краснодара: аналитика рынка	Анализ инвестиционной привлекательности недвижимости Краснодара	\N	published	/attached_assets/Screenshot_102_1754876855770.jpg	Инвестиции	["инвестиции", "Краснодар", "аналитика"]	1	2025-08-12 19:19:17.32618	\N	0	0	2025-08-12 19:19:17.326187	2025-08-12 19:19:52.371542
3	Как выбрать квартиру в новостройке: полное руководство	kak-vybrat-kvartiru-v-novostroyke-polnoe-rukovodstvo	При выборе квартиры в новостройке важно учитывать множество факторов. \n            \nОсновные критерии:\n1. Репутация застройщика - изучите его предыдущие проекты\n2. Документы на строительство - все должно быть в порядке\n3. Расположение - транспортная доступность и инфраструктура\n4. Планировка и качество отделки\n5. Сроки сдачи и возможные риски\n\nФинансовые аспекты:\n- Сравните цены с аналогичными объектами\n- Узнайте о возможностях рассрочки и ипотеки\n- Рассчитайте дополнительные расходы\n\nПравовые моменты:\n- Проверьте все документы на землю и строительство\n- Изучите договор долевого участия\n- Узнайте о страховании	Подробное руководство по выбору квартиры в новостройке с учетом всех важных факторов	Как выбрать квартиру в новостройке: полное руководство	Подробное руководство по выбору квартиры в новостройке с учетом всех важных факторов	\N	published	/attached_assets/Screenshot_100_1754873602744.jpg	Советы покупателям	["новостройка", "покупка", "советы"]	1	2025-08-12 19:19:16.904686	\N	1	0	2025-08-12 19:19:16.904696	2025-08-12 22:52:47.660453
6	Кешбек при покупке недвижимости: как получить максимум	keshbek-pri-pokupke-nedvizhimosti-kak-poluchit-maksimum	Кешбек при покупке недвижимости - отличная возможность сэкономить.\n\nВиды кешбека:\n- От застройщика (обычно 1-3% от стоимости)\n- От банка при оформлении ипотеки\n- От агентства недвижимости\n- Специальные акции и программы лояльности\n\nКак увеличить кешбек:\n1. Участвуйте в акциях застройщика\n2. Выбирайте правильное время покупки\n3. Используйте партнерские программы\n4. Оформляйте ипотеку в банках-партнерах\n\nУсловия получения:\n- Соблюдение сроков сделки\n- Предоставление всех документов\n- Выполнение условий программы\n\nНалоговые аспекты:\n- Кешбек может облагаться налогом\n- Ведите учет всех выплат\n- Консультируйтесь с налоговыми консультантами	Как максимально использовать программы кешбека при покупке недвижимости	Кешбек при покупке недвижимости: как получить максимум	Как максимально использовать программы кешбека при покупке недвижимости	\N	published	/attached_assets/Screenshot_104_1754918829200.jpg	Кешбек	["кешбек", "экономия", "покупка"]	1	2025-08-12 19:19:17.531338	\N	0	0	2025-08-12 19:19:17.531344	2025-08-12 19:19:52.371542
10	Лучшие районы Краснодара для инвестиций	лучшие-районы-краснодара-для-инвестиций	Подробный анализ районов города с точки зрения инвестиций в недвижимость	Анализ перспективных районов Краснодара для покупки недвижимости	\N	\N	\N	published		Районы Краснодара	районы, инвестиции, краснодар	1	2025-08-12 19:40:29.836905	\N	0	0	2025-08-12 19:40:29.838672	2025-08-12 19:40:29.838674
11	Статья без изображения	статья-без-изображения	<p>Содержание статьи без изображения</p>	<p>Краткое описание</p>	Статья без изображения	Краткое описание	\N	draft	/uploads/Screenshot_62_1755029158.png	Тест		1	2025-08-12 19:47:11.118292	\N	0	0	2025-08-12 19:47:11.120373	2025-08-12 20:06:01.88409
12	Тестовая статья	testovaya-statya	Содержание тестовой статьи	Краткое описание статьи	\N	\N	\N	draft	\N	Новости	\N	1	\N	\N	0	0	2025-08-12 21:58:01.764612	2025-08-12 21:58:01.764615
8	Тестовая статья в категории Тест	testovaya-statya-v-kategorii-test	Это тестовая статья для проверки отображения категорий в блоге.	Тестовая статья для проверки категорий	\N	\N	\N	published	\N	Тест	тест, категория	1	2025-08-12 19:29:17.877043	\N	2	0	2025-08-12 19:29:17.982118	2025-08-12 19:46:33.74723
13	123	123	<p>123<img src="../../uploads/components-charts-intro2x_1755036639.png" alt="Изображение" style="max-width: 100%; height: auto;"></p>	123	123	123	123	published	https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=250&fit=crop	Тест	Недвижимость и точка	1	2025-08-12 22:13:18.340498	\N	24	0	2025-08-12 22:11:04.043595	2025-08-12 22:53:40.815791
9	Обзор районов Краснодара: где лучше купить квартиру	obzor-rajonov-krasnodara	<p>Краснодар - динамично развивающийся город с множеством привлекательных районов для покупки недвижимости. В этом обзоре мы рассмотрим основные районы города и их особенности.</p><h3>Центральный район</h3><p>Сердце города с развитой инфраструктурой и высокими ценами на недвижимость.</p><h3>Прикубанский район</h3><p>Один из самых престижных районов с парками и современными ЖК.</p>	Подробный обзор лучших районов Краснодара для покупки недвижимости с анализом инфраструктуры и цен.	\N	\N	\N	published	\N	Районы Краснодара	районы, краснодар, недвижимость, инфраструктура	1	2025-08-12 19:39:31.807738	\N	1	0	2025-08-12 19:39:31.81034	2025-08-12 22:22:12.494365
14	123	123-1	<p>123</p>	123	123	123	123	published		Тест		1	2025-08-12 22:51:43.804984	\N	0	0	2025-08-12 22:51:43.804887	2025-08-12 22:51:43.806595
7	Тенденции рынка недвижимости в 2024 году	tendentsii-rynka-nedvizhimosti-v-2024-godu	Рынок недвижимости в 2024 году показывает интересные тенденции.\n\nОсновные тренды:\n- Рост спроса на комфорт-класс\n- Увеличение популярности готового жилья\n- Развитие пригородной недвижимости\n- Внедрение smart-технологий в ЖК\n\nРегиональные особенности:\n- Краснодар: стабильный рост цен\n- Сочи: высокий инвестиционный потенциал\n- Анапа: развитие курортной недвижимости\n\nПрогнозы на год:\n- Умеренный рост цен (5-10%)\n- Развитие ипотечного кредитования\n- Увеличение объемов строительства\n- Новые технологии в отрасли\n\nРекомендации покупателям:\n- Не откладывайте покупку надолго\n- Изучайте новые проекты\n- Следите за изменениями в законодательстве	Обзор ключевых тенденций и прогнозов развития рынка недвижимости	Тенденции рынка недвижимости в 2024 году	Обзор ключевых тенденций и прогнозов развития рынка недвижимости	\N	published	/attached_assets/Screenshot_105_1754923069170.jpg	Аналитика	["тенденции", "прогноз", "рынок"]	1	2025-08-12 19:19:17.734633	\N	1	0	2025-08-12 19:19:17.734641	2025-08-12 19:19:52.371545
15	фффф	ffff	<p>ффф</p>	ффф	ффф	ффф	фф	published		123333		1	2025-08-12 23:16:45.210947	\N	2	0	2025-08-12 23:16:45.210863	2025-08-12 23:16:45.212505
\.


--
-- Data for Name: blog_tags; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.blog_tags (id, name, slug, description, usage_count, created_at) FROM stdin;
\.


--
-- Data for Name: callback_requests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.callback_requests (id, name, phone, email, preferred_time, notes, interest, budget, timing, status, assigned_manager_id, manager_notes, created_at, processed_at) FROM stdin;
3	Тест Тестов	+7999123456	\N	\N	Заявка на кешбек 275 000 ₽ при покупке квартиры в ЖК Первое место стоимостью 5 000 000 ₽	\N	\N	\N	Новая	\N	\N	2025-08-14 10:54:06.80772	\N
4	Тест Тестов	+7999123456	\N	\N	Заявка на кешбек 275 000 ₽ при покупке квартиры в ЖК Первое место стоимостью 5 000 000 ₽	\N	\N	\N	Новая	\N	\N	2025-08-14 10:54:13.581271	\N
5	Демо Покупатель	123	\N	\N	Заявка на кешбек 60 000 ₽ при покупке квартиры в ЖК «Аврора» стоимостью 1 000 000 ₽	\N	\N	\N	Новая	\N	\N	2025-08-14 11:05:47.336392	\N
\.


--
-- Data for Name: cashback_applications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cashback_applications (id, user_id, property_id, property_name, property_type, property_size, property_price, complex_name, developer_name, cashback_amount, cashback_percent, status, application_date, approved_date, payout_date, notes, approved_by_manager_id, manager_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cashback_payouts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cashback_payouts (id, user_id, amount, status, payment_method, admin_notes, requested_at, processed_at) FROM stdin;
\.


--
-- Data for Name: cashback_records; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cashback_records (id, user_id, property_id, property_name, property_price, amount, percentage, status, created_at, approved_at, paid_at) FROM stdin;
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cities (id, name, slug, is_active, is_default, phone, email, address, latitude, longitude, zoom_level, description, meta_title, meta_description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: client_property_recommendations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.client_property_recommendations (id, manager_id, client_id, search_id, message, sent_at, viewed_at) FROM stdin;
\.


--
-- Data for Name: collection_properties; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.collection_properties (id, collection_id, property_id, property_name, property_price, complex_name, property_type, property_size, manager_note, order_index, created_at) FROM stdin;
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.collections (id, title, description, created_by_manager_id, assigned_to_user_id, status, is_public, tags, created_at, updated_at, sent_at, viewed_at) FROM stdin;
\.


--
-- Data for Name: developer_appointments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.developer_appointments (id, user_id, property_id, developer_name, complex_name, appointment_date, appointment_time, status, client_name, client_phone, notes, created_at, developer_id) FROM stdin;
\.


--
-- Data for Name: developers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.developers (id, name, slug, full_name, established_year, description, logo_url, phone, email, website, address, latitude, longitude, zoom_level, total_complexes, total_properties, properties_sold, rating, experience_years, min_price, max_cashback_percent, inn, kpp, ogrn, legal_address, bank_name, bank_bik, bank_account, features, infrastructure, is_active, is_partner, created_at, updated_at) FROM stdin;
2	DOGMA	dogma	ООО "ДОГМА"	2008	Современная строительная компания, специализирующаяся на комфортном жилье с уникальной архитектурой. Известна инновационными решениями в области жилищного строительства.	\N	+7 (861) 205-77-99	\N	dogma-krd.ru	г. Краснодар, ул. Красная, 122	45.040123	38.976854	13	8	850	2500	4.7	16	6200000	9.5	2312000279	231200027	1002300002567	г. Краснодар, ул. Красная, 122	ПАО СБЕРБАНК	040349602	40702810234567890123	["Инновационные решения", "Уникальная архитектура", "Современные технологии", "Качественное исполнение"]	["Детские площадки", "Фитнес-центр", "Охрана", "Парковка", "Благоустройство"]	t	t	2025-08-14 19:39:57.749486	2025-08-14 19:39:57.749486
3	ТОЧНО	tochno	ООО "ТОЧНО"	2012	Застройщик премиального сегмента, создающий жилые комплексы с высоким уровнем комфорта. Особое внимание уделяется качеству строительства и архитектурным решениям.	\N	+7 (861) 201-05-55	\N	tochno-krd.ru	г. Краснодар, пр. Чекистов, 25	45.028765	38.982147	13	6	650	1800	4.9	12	7500000	8.5	2312000380	231200038	1002300003678	г. Краснодар, пр. Чекистов, 25	ПАО СБЕРБАНК	040349602	40702810345678901234	["Премиальный сегмент", "Высокий уровень комфорта", "Архитектурные решения", "Энергоэффективность"]	["Детский сад", "Спортивные площадки", "Медицинский центр", "Охрана", "Подземная парковка"]	t	t	2025-08-14 19:39:57.749486	2025-08-14 19:39:57.749486
4	AVA GROUP	ava-group	ООО "АВА ГРУПП"	2015	Динамично развивающаяся строительная компания, специализирующаяся на малоэтажном и среднеэтажном строительстве. Отличается индивидуальным подходом к каждому проекту.	\N	+7 (861) 298-44-33	\N	avagroup.ru	г. Краснодар, ул. Северная, 326	45.052341	38.968745	13	5	420	1200	4.6	9	4800000	7	2312000481	231200048	1002300004789	г. Краснодар, ул. Северная, 326	ПАО СБЕРБАНК	040349602	40702810456789012345	["Индивидуальный подход", "Малоэтажное строительство", "Гибкие условия покупки"]	["Детские площадки", "Спортплощадки", "Парковка", "Благоустройство"]	t	t	2025-08-14 19:39:57.749486	2025-08-14 19:39:57.749486
5	ЮГСТРОЙИНВЕСТ	yugstroyinvest	ООО "ЮГСТРОЙИНВЕСТ"	2009	Крупный застройщик Краснодарского края с опытом работы более 15 лет. Специализируется на строительстве жилых комплексов комфорт-класса с развитой инфраструктурой.	\N	+7 (861) 992-11-22	\N	yugstroyinvest.ru	г. Краснодар, ул. Тургенева, 158	45.031287	38.979652	13	9	1200	3500	4.7	15	5800000	9	2312000582	231200058	1002300005890	г. Краснодар, ул. Тургенева, 158	ПАО СБЕРБАНК	040349602	40702810567890123456	["Развитая инфраструктура", "Комфорт-класс", "Соблюдение сроков", "Ипотечные программы"]	["Детский сад", "Школа", "Торговые центры", "Фитнес-центр", "Охрана", "Парковка"]	t	t	2025-08-14 19:39:57.749486	2025-08-14 19:39:57.749486
1	ГК ССК	gk-ssk	ООО "Группа Компаний ССК"	1994	Крупнейшая строительная компания Юга России, специализирующаяся на жилищном строительстве. Основана в 1994 году, за время работы построено более 2,5 миллионов квадратных метров жилья.	\N	+7 (861) 992-99-55	\N	ssk-group.ru	г. Краснодар, ул. Мира, 45	45.03547	38.975313	13	12	1500	5000	4.8	30	5500000	10	2312345678	231201001	1122300012345	г. Краснодар, ул. Красная, 180, оф. 301	ПАО "Сбербанк России"	040349602	40702810100000012345	["Собственное производство", "Контроль качества", "Соблюдение сроков", "Ипотечные программы"]	["Детский сад", "Спортплощадки", "Торговые центры", "Парковка", "Благоустройство", "Охрана"]	t	t	2025-08-14 19:39:57.749486	2025-08-14 19:39:57.749486
6	МЕТРИКС	metriks	ООО "МЕТРИКС"	2015	Современный застройщик Краснодара, специализирующийся на комфортном жилье с развитой инфраструктурой.	\N	+7 (861) 210-50-60	\N	\N	г. Краснодар, ул. Северная, 324	45.046	38.982	13	8	450	0	4.6	10	6500000	8.5	2312300006	231201006	1122300000066	г. Краснодар, ул. Красная, 160	ПАО "Сбербанк России"	040349602	40702810100000000006	["Собственное производство", "Контроль качества", "Соблюдение сроков", "Ипотечные программы"]	["Детский сад", "Спортплощадки", "Торговые центры", "Парковка", "Благоустройство", "Охрана"]	t	t	2025-08-14 19:48:49.278551	2025-08-14 19:48:49.278551
7	ДАРСТРОЙ	darstroy	ООО "ДАРСТРОЙ"	2012	Надежный застройщик с многолетним опытом строительства качественного жилья в Краснодаре.	\N	+7 (861) 275-88-99	\N	\N	г. Краснодар, ул. Тургенева, 158	45.047	38.984	13	6	280	0	4.4	13	5200000	7.8	2312300007	231201007	1122300000077	г. Краснодар, ул. Северная, 170	ПАО "ВТБ"	040349699	40702810100000000007	["Собственное производство", "Контроль качества", "Соблюдение сроков", "Ипотечные программы"]	["Детский сад", "Спортплощадки", "Торговые центры", "Парковка", "Благоустройство", "Охрана"]	t	t	2025-08-14 19:48:49.278551	2025-08-14 19:48:49.278551
8	Ромекс Девелопмент	romeks-development	ООО "Ромекс Девелопмент"	2016	Инновационный застройщик с современным подходом к строительству жилья.	\N	+7 (861) 240-30-40	\N	\N	г. Краснодар, ул. Красная, 120	45.0411	38.9721	13	5	250	0	4.3	9	5800000	7.5	2312340001	231201001	1122300012350	г. Краснодар, ул. Красная, 120, оф. 205	ПАО "Сбербанк России"	040349602	40702810100000012350	["Собственное производство", "Контроль качества", "Соблюдение сроков", "Ипотечные программы"]	["Детский сад", "Спортплощадки", "Торговые центры", "Парковка", "Благоустройство", "Охрана"]	t	t	2025-08-14 19:56:54.447739	2025-08-14 19:56:54.447739
9	Европея	evropeya	ООО "Европея"	2014	Европейские стандарты строительства в Краснодаре.	\N	+7 (861) 250-40-50	\N	\N	г. Краснодар, ул. Тургенева, 95	45.0356	38.9698	13	7	380	0	4.5	11	6200000	8	2312340002	231201002	1122300012351	г. Краснодар, ул. Тургенева, 95	ПАО "ВТБ"	040349699	40702810100000012351	["Европейские стандарты", "Качественные материалы", "Индивидуальный подход"]	["Детские площадки", "Фитнес-центр", "Кафе", "Паркинг", "Консьерж"]	t	t	2025-08-14 19:56:54.447739	2025-08-14 19:56:54.447739
10	Неометрия	neometriya	ООО "Неометрия"	2017	Геометрия комфорта в каждом квадратном метре.	\N	+7 (861) 260-50-60	\N	\N	г. Краснодар, ул. Северная, 220	45.0445	38.9623	13	4	200	0	4.4	8	5500000	7	2312340003	231201003	1122300012352	г. Краснодар, ул. Северная, 220	ПАО "Альфа-Банк"	040349593	40702810100000012352	["Современный дизайн", "Эргономичные планировки", "Энергоэффективность"]	["Детский сад", "Спорткомплекс", "Магазины", "Автопарковка"]	t	t	2025-08-14 19:56:54.447739	2025-08-14 19:56:54.447739
11	Гарантия	garantiya	ООО "Гарантия"	2013	Гарантированное качество и надежность строительства.	\N	+7 (861) 270-60-70	\N	\N	г. Краснодар, ул. Красная, 85	45.0389	38.9756	13	8	420	0	4.6	12	5900000	8.5	2312340004	231201004	1122300012353	г. Краснодар, ул. Красная, 85	ПАО "Сбербанк России"	040349602	40702810100000012353	["Гарантия качества", "Проверенные технологии", "Долговечность"]	["Школа", "Поликлиника", "Торговый центр", "Спортзал", "Парк"]	t	t	2025-08-14 19:56:54.447739	2025-08-14 19:56:54.447739
12	БауИнвест	bauinvest	ООО "БауИнвест"	2018	Строительные инвестиции с немецким качеством.	\N	+7 (861) 280-70-80	\N	\N	г. Краснодар, ул. Тургенева, 140	45.0367	38.9687	13	3	180	0	4.2	7	6100000	6.8	2312340005	231201005	1122300012354	г. Краснодар, ул. Тургенева, 140	ПАО "ВТБ"	040349699	40702810100000012354	["Немецкие технологии", "Экологичность", "Инновации"]	["Детские площадки", "Велопарковка", "Кофейни", "Фармацевт", "Видеонаблюдение"]	t	t	2025-08-14 19:56:54.447739	2025-08-14 19:56:54.447739
\.


--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.districts (id, name, slug) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.documents (id, user_id, filename, original_filename, file_type, file_size, file_path, document_type, status, reviewed_at, reviewer_notes, reviewed_by_manager_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: favorite_properties; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.favorite_properties (id, user_id, property_id, property_name, property_type, property_size, property_price, complex_name, developer_name, property_image, property_url, cashback_amount, cashback_percent, created_at) FROM stdin;
5	5	56	Квартира в ЖК Альфа	apartment	65	5600000	ЖК Альфа	Застройщик Альфа	/static/images/property_56.jpg	/object/56	280000	5	2025-08-11 00:30:56
6	3	8	Студия в центре	studio	28.5	3200000	ЖК Центральный	ГК Центр	/static/images/property_8.jpg	/object/8	160000	5	2025-08-11 00:30:56
7	4	11	Двушка в спальном районе	apartment	54.3	4100000	ЖК Уют	Застройщик Уют	/static/images/property_11.jpg	/object/11	205000	5	2025-08-11 00:30:56
8	3	18	Таунхаус премиум	townhouse	145	12800000	Коттеджный поселок	Премиум Строй	/static/images/property_18.jpg	/object/18	640000	5	2025-08-11 00:30:56
9	4	25	Трехкомнатная семейная	apartment	78.2	7200000	ЖК Семейный	Семейный Девелопмент	/static/images/property_25.jpg	/object/25	360000	5	2025-08-11 00:30:56
10	2	38			0	3367362			https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	168368	5	2025-08-14 09:01:51.418897
11	2	15			0	3395184			https://images.unsplash.com/photo-1565182999561-18d7dc61c393?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	169759	5	2025-08-14 09:01:54.940518
12	2	2			0	3551955			https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	177598	5	2025-08-14 09:01:57.534708
13	2	52			0	3130925			https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	156546	5	2025-08-14 11:07:02.933242
14	2	26			0	3707314			https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	185366	5	2025-08-14 11:07:08.120333
15	2	90			0	3619679			https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	180984	5	2025-08-14 11:16:55.621193
16	2	96			0	4906126			https://images.unsplash.com/photo-1484101403633-562f891dc89a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	245306	5	2025-08-14 12:27:11.769777
17	2	64			0	5294267			https://images.unsplash.com/photo-1571055107559-3e67626fa8be?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80	\N	264713	5	2025-08-14 13:40:00.18395
18	2	209			0	2800000			https://images.unsplash.com/photo-1502672023488-70e25813eb80?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60	\N	140000	5	2025-08-15 12:19:41.146918
19	2	11			0	3200000			https://via.placeholder.com/800x600/0088CC/FFFFFF?text=%D0%A1%D1%82%D1%83%D0%B4%D0%B8%D1%8F+28+%D0%BC%C2%B2	\N	160000	5	2025-08-15 12:19:43.64371
20	2	204			0	3200000			https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60	\N	160000	5	2025-08-15 12:19:46.038272
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.favorites (id, user_id, property_id, created_at) FROM stdin;
\.


--
-- Data for Name: manager_saved_searches; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.manager_saved_searches (id, manager_id, name, description, search_type, location, property_type, price_min, price_max, size_min, size_max, developer, complex_name, floor_min, floor_max, cashback_min, additional_filters, is_template, usage_count, created_at, updated_at, last_used) FROM stdin;
1	1	Поиск 2-комн в Центральный, 0-10 млн	\N	properties	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"districts": ["\\u0426\\u0435\\u043d\\u0442\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439"], "developers": [], "rooms": ["2-\\u043a\\u043e\\u043c\\u043d"], "completion": [], "propertyClass": [], "wallMaterial": [], "floorsTotal": [], "priceFrom": "", "priceTo": "10", "areaFrom": "", "areaTo": ""}	f	1	2025-08-14 07:58:48.695621	2025-08-14 07:59:20.779791	2025-08-14 07:59:20.778794
\.


--
-- Data for Name: managers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.managers (id, email, password_hash, first_name, last_name, phone, "position", can_approve_cashback, can_manage_documents, can_create_collections, max_cashback_approval, is_active, profile_image, manager_id, created_at, updated_at, last_login) FROM stdin;
2	manager2@inback.ru	scrypt:32768:8:1$IFd63Sugr9ETxqJh$5037b8cd882ea012f7a882fde228003b9f10e3b6d57c62f28d6d6c4342f43653e509bc07414205ed44e6c0804bd0c198c7b3154c0557551ebfef4bd1654acb78	Анна	Петрова	+7 (999) 234-56-78	Менеджер по продажам	\N	\N	\N	\N	t	\N	anna_mgr	2025-08-11 19:25:42.735161	2025-08-11 21:53:04.242931	\N
1	manager@inback.ru	scrypt:32768:8:1$g8ISprLJeH77Uuv5$b878fda08b06bfbc240dfcc3fc983ebfe44c289552374309239ac9d65ee1f792553631f824c41ca4fa7cfebc83cb336e807de9809a15023cb3c5725a8567d687	Станислав	Менеджер	+7 (999) 123-45-67	Старший менеджер	\N	\N	\N	\N	t	\N	stanislaw_mgr	2025-08-11 19:25:42.735161	2025-08-14 10:16:27.57935	2025-08-14 10:16:27.578754
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notifications (id, user_id, title, message, type, icon, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: recommendation_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recommendation_categories (id, name, description, manager_id, client_id, color, is_active, recommendations_count, last_used, created_at, updated_at) FROM stdin;
2	Новая	Новые объекты на рынке	1	2	#10B981	t	\N	\N	2025-08-14 10:03:24.602665	\N
3	Инвестиционная	Инвестиционные объекты	1	2	#3B82F6	t	\N	\N	2025-08-14 10:03:24.602665	\N
4	Семейная	Объекты для семей	1	2	#F59E0B	t	\N	\N	2025-08-14 10:03:24.602665	\N
5	Премиум	Премиальная недвижимость	1	2	#8B5CF6	t	\N	\N	2025-08-14 10:03:24.602665	\N
6	Эконом	Доступные объекты	1	2	#EF4444	t	\N	\N	2025-08-14 10:03:24.602665	\N
7	Черемушки	\N	1	2	blue	t	1	2025-08-14 10:15:54.003485	2025-08-14 10:15:53.893717	2025-08-14 10:15:54.004305
\.


--
-- Data for Name: recommendation_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recommendation_templates (id, manager_id, name, description, recommendation_type, default_title, default_description, default_notes, default_highlighted_features, default_priority, is_active, usage_count, created_at, updated_at, last_used) FROM stdin;
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.recommendations (id, manager_id, client_id, category_id, title, description, recommendation_type, item_id, item_name, item_data, manager_notes, highlighted_features, priority_level, status, viewed_at, responded_at, client_response, client_notes, viewing_requested, viewing_scheduled_at, created_at, sent_at, expires_at) FROM stdin;
5	1	3	\N	Элитная квартира	3-комнатная в престижном районе	property	1	3-комнатная квартира 87.0 м² в ЖК Первое место	\N	\N	\N	\N	viewed	\N	\N	\N	\N	\N	\N	2025-08-11 17:20:00	2025-08-11 17:20:00	\N
6	2	4	\N	Семейный дом	Прекрасный дом для большой семьи	property	3	Дом 233.3 м² в ЖК Седьмое небо	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-11 18:00:00	2025-08-11 18:00:00	\N
8	2	5	\N	Новостройка со скидкой	Отличное предложение в новом ЖК	property	15	Квартира в новом комплексе	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 11:15:00	2025-08-12 11:15:00	\N
9	1	3	\N	Таунхаус премиум	Таунхаус в зеленом районе	property	5	Таунхаус 195.7 м² в ЖК Панорама	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 14:45:00	2025-08-12 14:45:00	\N
11	2	3	\N	Отличная квартира в центре	Престижный район с развитой инфраструктурой	property	12	Квартира в центре города	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 18:30:00	2025-08-12 18:30:00	\N
12	1	4	\N	Семейный дом	Идеально для семьи с детьми	property	18	Дом в тихом районе	\N	\N	\N	\N	viewed	\N	\N	\N	\N	\N	\N	2025-08-12 19:15:00	2025-08-12 19:15:00	\N
13	2	5	\N	Инвестиционная студия	Высокая доходность от аренды	property	8	Студия в новом ЖК	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 20:00:00	2025-08-12 20:00:00	\N
23	1	2	2	Рекомендую: Объект 52	новая	property	52	Объект 52	{}	потому	\N	normal	viewed	2025-08-14 09:42:56.282165	\N	\N	\N	f	\N	2025-08-14 09:42:00.446866	2025-08-14 09:42:00.446869	\N
1	1	2	2	Рекомендуемая квартира	Отличная квартира для вашей семьи	property	1	Квартира в ЖК Первое место	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-11 00:34:16	2025-08-11 00:34:16	\N
2	1	2	2	Ещё одна рекомендация	Хорошее предложение по цене	property	2	Студия в ЖК Аврора	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-11 15:34:54	2025-08-11 15:34:54	\N
7	1	2	3	Инвестиционная квартира	Хорошая квартира для сдачи в аренду	property	7	1-комнатная квартира 55.7 м²	\N	\N	\N	\N	responded	\N	\N	\N	\N	\N	\N	2025-08-12 09:30:00	2025-08-12 09:30:00	\N
3	1	2	4	Третья рекомендация	Отличное расположение	property	3	Дом в ЖК Седьмое небо	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-11 15:34:54	2025-08-11 15:34:54	\N
4	1	2	5	Отличная студия	Студия в центре по отличной цене	property	2	Студия 27.5 м² в ЖК Аврора	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-11 16:45:00	2025-08-11 16:45:00	\N
10	2	2	5	Квартира с видом	Квартира с прекрасным видом на город	property	25	Квартира с панорамным видом	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 16:20:00	2025-08-12 16:20:00	\N
15	1	6	\N	Элитный пентхаус	Роскошный пентхаус с панорамным видом	property	45	Пентхаус премиум класса	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-12 21:30:00	2025-08-12 21:30:00	\N
17	1	3	\N	Квартира с ремонтом	Готова к заселению	property	33	Квартира под ключ	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-13 09:45:00	2025-08-13 09:45:00	\N
18	2	4	\N	Новостройка со скидкой	Специальное предложение от застройщика	property	67	Квартира со скидкой 15%	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-13 11:20:00	2025-08-13 11:20:00	\N
19	1	5	\N	Апартаменты бизнес-класса	Современный жилой комплекс	property	78	Апартаменты в бизнес-центре	\N	\N	\N	\N	viewed	\N	\N	\N	\N	\N	\N	2025-08-13 12:50:00	2025-08-13 12:50:00	\N
20	2	6	\N	Лофт в историческом районе	Уникальная планировка в старом городе	property	92	Лофт с высокими потолками	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-13 14:25:00	2025-08-13 14:25:00	\N
21	1	7	\N	Коттедж за городом	Загородный дом с большим участком	property	105	Коттедж в коттеджном поселке	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-13 15:40:00	2025-08-13 15:40:00	\N
16	2	2	3	Таунхаус с участком	Собственный участок и гараж	property	28	Таунхаус с садом	\N	\N	\N	\N	responded	\N	\N	\N	\N	\N	\N	2025-08-13 08:15:00	2025-08-13 08:15:00	\N
22	2	2	4	Квартира для молодой семьи	Отличное соотношение цены и качества	property	115	Двушка в спальном районе	\N	\N	\N	\N	pending	\N	\N	\N	\N	\N	\N	2025-08-13 17:10:00	2025-08-13 17:10:00	\N
24	1	2	7	Рекомендую: Объект 177777	123	property	162	Объект 162	{}	123	\N	high	sent	\N	\N	\N	\N	f	\N	2025-08-14 10:15:54.106939	2025-08-14 10:15:54.106943	\N
\.


--
-- Data for Name: residential_complexes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.residential_complexes (id, name, slug, district_id, developer_id, cashback_rate) FROM stdin;
1	ЖК «Первое место»	pervoe-mesto	\N	\N	5.50
2	ЖК «Аврора»	avrora	\N	\N	6.00
3	ЖК «Седьмое небо»	sedmoe-nebo	\N	\N	7.00
4	ЖК «Морская волна»	morskaya-volna	\N	\N	5.00
5	ЖК «Комплекс-3»	kompleks-3	\N	\N	6.50
6	ЖК «Комплекс-8»	kompleks-8	\N	\N	5.50
7	ЖК «Комплекс-18»	kompleks-18	\N	\N	7.50
8	ЖК «Комплекс-25»	kompleks-25	\N	\N	8.00
\.


--
-- Data for Name: room_types; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.room_types (id, name, rooms_count) FROM stdin;
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.saved_searches (id, user_id, name, description, search_type, location, property_type, price_min, price_max, size_min, size_max, developer, complex_name, floor_min, floor_max, cashback_min, additional_filters, notify_new_matches, last_notification_sent, created_from_quiz, created_at, updated_at, last_used) FROM stdin;
2	2	Поиск 2	Поиск недвижимости	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-05 00:32:09	2025-07-05 00:32:09	\N
7	4	Дома и таунхаусы	Индивидуальные дома	house	Прикубанский округ	дом	10000000	25000000	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-08-08 16:45:00	2025-08-08 16:45:00	\N
8	5	Новостройки	Квартиры в новостройках	apartment	Краснодар	квартира	3000000	12000000	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-08-09 11:00:00	2025-08-09 11:00:00	\N
10	3	Инвестиции	Квартиры для инвестиций	investment	Краснодар	квартира	2500000	6000000	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-08-11 08:45:00	2025-08-11 08:45:00	\N
11	2	Поиск недвижимости #11	Дополнительный поиск	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-15 10:00:00	2025-07-15 10:00:00	\N
13	5	Элитные квартиры	Поиск элитного жилья	apartment	Центральный район	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-17 12:00:00	2025-07-17 12:00:00	\N
15	4	Дома коттеджи	Индивидуальные дома	house	Прикубанский округ	дом	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-19 14:00:00	2025-07-19 14:00:00	\N
16	6	Инвестиционные объекты	Для инвестиций	investment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-20 15:00:00	2025-07-20 15:00:00	\N
17	7	Новостройки бюджет	Бюджетные новостройки	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-21 16:00:00	2025-07-21 16:00:00	\N
18	2	Таунхаусы премиум	Премиум таунхаусы	townhouse	Прикубанский округ	таунхаус	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-07-22 17:00:00	2025-07-22 17:00:00	\N
19	3	ЖК конкретный	Поиск в конкретном ЖК	complex	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-23 18:00:00	2025-07-23 18:00:00	\N
20	5	Срочная продажа	Объекты со скидками	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-24 19:00:00	2025-07-24 19:00:00	\N
21	4	Квартиры улучшенной планировки	Евроремонт и планировка	apartment	Центральный район	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-25 10:00:00	2025-07-25 10:00:00	\N
22	6	Апартаменты бизнес-класса	Бизнес класс апартаменты	apartment	Центральный район	апартаменты	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-07-26 11:00:00	2025-07-26 11:00:00	\N
23	7	Семейные квартиры	Для больших семей	apartment	Прикубанский округ	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-27 12:00:00	2025-07-27 12:00:00	\N
24	2	Объекты с кэшбэком	Максимальный кэшбэк	cashback	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-28 13:00:00	2025-07-28 13:00:00	\N
25	3	Готовые квартиры	Квартиры с ремонтом	ready	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-29 14:00:00	2025-07-29 14:00:00	\N
26	5	Пентхаусы	Элитные пентхаусы	penthouse	Центральный район	пентхаус	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-07-30 15:00:00	2025-07-30 15:00:00	\N
27	4	Квартиры первичка	Первичный рынок	primary	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-31 16:00:00	2025-07-31 16:00:00	\N
1	2	Поиск квартир	Автоматически созданный поиск	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-01 00:32:09	2025-08-13 19:30:29.664079	2025-08-13 19:30:29.662839
3	2	Поиск 3	Дополнительный поиск	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-04 00:32:09	2025-08-13 19:31:49.226596	2025-08-13 19:31:49.226078
12	2	Поиск недвижимости #12	Поиск для семьи	apartment	Краснодар	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	2025-07-16 11:00:00	2025-07-16 11:00:00	\N
4	2	Студии в центре	Поиск студий в центре города	studio	Центральный район	студия	2000000	4000000	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["Студия"], "districts": ["Центральный"], "priceFrom": "2000000", "priceTo": "4000000"}	t	\N	\N	2025-08-05 10:15:00	2025-08-05 10:15:00	\N
14	2	Студии центр	Студии в центре	studio	Центральный район	студия	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["Студия"], "districts": ["Центральный"], "priceFrom": "2000000", "priceTo": "4000000"}	f	\N	\N	2025-07-18 13:00:00	2025-07-18 13:00:00	\N
6	2	Элитное жилье	Поиск элитных квартир	apartment	Центральный район	квартира	15000000	\N	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["1"], "districts": ["Западный"], "priceFrom": "3000000", "priceTo": "5000000"}	f	\N	\N	2025-08-07 09:30:00	2025-08-07 09:30:00	\N
5	2	Двушки до 8 млн	Двухкомнатные квартиры до 8 млн	apartment	Краснодар	2-комнатная	\N	8000000	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["2"], "priceFrom": "0", "priceTo": "8000000"}	t	\N	\N	2025-08-06 14:20:00	2025-08-06 14:20:00	\N
9	2	ЖК Панорама	Поиск в конкретном ЖК	complex	Прикубанский округ	квартира	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["3"], "priceFrom": "5000000", "priceTo": "15000000"}	t	\N	\N	2025-08-10 13:15:00	2025-08-10 13:15:00	\N
29	2	Комплексный поиск (ВСЕ фильтры)	Тест всех возможных фильтров системы	properties	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"districts": ["Центральный", "Западный"], "developers": ["СК \\"Премьера\\""], "rooms": ["1-комн", "2-комн"], "completion": ["1 кв. 2025"], "propertyClass": ["эконом"], "wallMaterial": ["монолит"], "floorsTotal": ["до 10 этажей"], "priceFrom": "5", "priceTo": "15", "areaFrom": "30", "areaTo": "80"}	t	\N	\N	2025-08-14 08:20:37.106547	2025-08-14 08:20:37.106547	2025-08-14 08:20:37.106547
28	2	От менеджера: Поиск 2-комн в Центральный, 0-15 млн	111	properties	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"districts": ["Центральный"], "developers": [], "rooms": ["2-комн"], "completion": [], "propertyClass": [], "wallMaterial": [], "floorsTotal": [], "priceFrom": "", "priceTo": "15", "areaFrom": "", "areaTo": ""}	t	\N	f	2025-08-14 07:59:20.570256	2025-08-14 09:17:32.507672	2025-08-14 09:17:32.506195
30	2	Поиск 4+-комн , 0-44 млн	\N	properties	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"rooms": ["4+-\\u043a\\u043e\\u043c\\u043d"], "priceTo": "44"}	t	\N	f	2025-08-14 09:18:54.326992	2025-08-14 09:29:06.96176	2025-08-14 09:29:06.960534
\.


--
-- Data for Name: search_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.search_categories (id, name, category_type, slug, created_at) FROM stdin;
\.


--
-- Data for Name: sent_searches; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sent_searches (id, manager_id, client_id, manager_search_id, name, description, additional_filters, status, viewed_at, applied_at, expires_at, sent_at) FROM stdin;
1	1	2	1	Поиск 2-комн в Центральный, 0-15 млн	\N	{"districts": ["Центральный"], "developers": [], "rooms": ["2-комн"], "completion": [], "propertyClass": [], "wallMaterial": [], "floorsTotal": [], "priceFrom": "", "priceTo": "15", "areaFrom": "", "areaTo": ""}	sent	\N	\N	\N	2025-08-14 07:59:20.674604
\.


--
-- Data for Name: streets; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.streets (id, name, slug, district_id) FROM stdin;
1	Гаврилова ул.	гаврилова-ул	\N
2	Гагарина ул.	гагарина-ул	\N
3	Гагаринский бульвар	гагаринскии-бульвар	\N
4	Газовиков ул.	газовиков-ул	\N
5	Галльская ул.	галльская-ул	\N
6	Гамбургская ул.	гамбургская-ул	\N
7	Ганноверская ул.	ганноверская-ул	\N
8	Гаражная ул.	гаражная-ул	\N
9	Гаражный пер.	гаражныи-пер	\N
10	Гасконская ул.	гасконская-ул	\N
11	Гастелло ул.	гастелло-ул	\N
12	Геленджикская ул.	геленджикская-ул	\N
13	Геленджикский проезд	геленджикскии-проезд	\N
14	Генерала Мищенко ул.	генерала-мищенко-ул	\N
15	Генерала Петрова ул.	генерала-петрова-ул	\N
16	Генерала Трошева ул.	генерала-трошева-ул	\N
17	Генеральная ул.	генеральная-ул	\N
18	Геодезическая ул.	геодезическая-ул	\N
19	Геологическая ул.	геологическая-ул	\N
20	Геологический пер.	геологическии-пер	\N
21	Георгия Димитрова пл.	георгия-димитрова-пл	\N
22	Героев-Разведчиков ул.	героев-разведчиков-ул	\N
23	Героя Аверкиева ул.	героя-аверкиева-ул	\N
24	Героя Владислава Посадского ул.	героя-владислава-посадского-ул	\N
25	Героя Сарабеева ул.	героя-сарабеева-ул	\N
26	Героя Яцкова ул.	героя-яцкова-ул	\N
27	Герцена проезд	герцена-проезд	\N
28	Герцена ул.	герцена-ул	\N
29	Гёте пр-кт.	гете-пр-кт	\N
30	Гиагинская ул.	гиагинская-ул	\N
31	Гидростроителей ул.	гидростроителеи-ул	\N
32	Гимназическая ул.	гимназическая-ул	\N
33	Глинки ул.	глинки-ул	\N
34	Глиняный пер.	глиняныи-пер	\N
35	Глубинный пер.	глубинныи-пер	\N
36	Глухой пер.	глухои-пер	\N
37	Гоголя ул.	гоголя-ул	\N
38	Гоголя пер.	гоголя-пер	\N
39	Гоголя (Пашковский) ул.	гоголя-пашковскии-ул	\N
40	Голубиная ул.	голубиная-ул	\N
41	Голубицкая ул.	голубицкая-ул	\N
42	Гомельская ул.	гомельская-ул	\N
43	Гончарная ул.	гончарная-ул	\N
44	Горная ул.	горная-ул	\N
45	Горогороды ул.	горогороды-ул	\N
46	Горького ул.	горького-ул	\N
47	Горького сквер	горького-сквер	\N
48	Горячеключевская ул.	горячеключевская-ул	\N
49	Грабина ул.	грабина-ул	\N
50	Гражданская ул.	гражданская-ул	\N
51	Гранатовая ул.	гранатовая-ул	\N
52	Гренадерская ул.	гренадерская-ул	\N
53	Грибоедова ул.	грибоедова-ул	\N
54	Григория Пономаренко ул.	григория-пономаренко-ул	\N
55	Грозненская ул.	грозненская-ул	\N
56	Грушевая ул.	грушевая-ул	\N
57	Грушевая (СНТ Ветерок) ул.	грушевая-снт-ветерок-ул	\N
58	Грушевая (СНТ Животновод) ул.	грушевая-снт-животновод-ул	\N
59	Грушевая (СНТ Радист) ул.	грушевая-снт-радист-ул	\N
60	Грушевая (СНТ Урожай) ул.	грушевая-снт-урожаи-ул	\N
61	Грушевая (СНТ Янтарь) ул.	грушевая-снт-янтарь-ул	\N
62	Гуденко ул.	гуденко-ул	\N
63	Гудимы ул.	гудимы-ул	\N
64	Дагестанская ул.	дагестанская-ул	\N
65	Дальний бульвар	дальнии-бульвар	\N
66	Дальний проезд	дальнии-проезд	\N
67	Дальняя ул.	дальняя-ул	\N
68	Дальняя (СНТ Солнышко) ул.	дальняя-снт-солнышко-ул	\N
69	Дамаева ул.	дамаева-ул	\N
70	Дачная ул.	дачная-ул	\N
71	Дворцовая ул.	дворцовая-ул	\N
72	Дежнёва ул.	дежнева-ул	\N
73	Декабристов ул.	декабристов-ул	\N
74	Декоративная ул.	декоративная-ул	\N
75	Дементия Красюка ул.	дементия-красюка-ул	\N
76	Демидовская ул.	демидовская-ул	\N
77	Демидовский проезд	демидовскии-проезд	\N
78	Дёмина ул.	демина-ул	\N
79	Демуса ул.	демуса-ул	\N
80	Деповская ул.	деповская-ул	\N
81	Деповской проезд	деповскои-проезд	\N
82	Депутатская ул.	депутатская-ул	\N
83	Дербентская ул.	дербентская-ул	\N
84	Дербентский проезд	дербентскии-проезд	\N
85	Детский сквер	детскии-сквер	\N
86	Джубгинская ул.	джубгинская-ул	\N
87	Дзержинского ул.	дзержинского-ул	\N
88	Дикуна ул.	дикуна-ул	\N
89	Димитрова ул.	димитрова-ул	\N
90	Динской проезд	динскои-проезд	\N
91	Длинная ул.	длинная-ул	\N
92	Дмитриевская Дамба ул.	дмитриевская-дамба-ул	\N
93	Дмитрия Благоева ул.	дмитрия-благоева-ул	\N
94	Дмитрия Донского ул.	дмитрия-донского-ул	\N
95	Дмитрия Пожарского ул.	дмитрия-пожарского-ул	\N
96	Днепровская ул.	днепровская-ул	\N
97	Днестровская ул.	днестровская-ул	\N
98	Добрая ул.	добрая-ул	\N
99	Дозорная ул.	дозорная-ул	\N
100	Докучаева пер.	докучаева-пер	\N
101	Должанская ул.	должанская-ул	\N
102	Домбайская ул.	домбаиская-ул	\N
103	Донская ул.	донская-ул	\N
104	Дорожная ул.	дорожная-ул	\N
105	Достоевского ул.	достоевского-ул	\N
106	Драгунская ул.	драгунская-ул	\N
107	Драгунский проезд	драгунскии-проезд	\N
108	Дрезденская ул.	дрезденская-ул	\N
109	Дружная ул.	дружная-ул	\N
110	Дружный проезд	дружныи-проезд	\N
111	Дубинский сквер	дубинскии-сквер	\N
112	Дубинский пер.	дубинскии-пер	\N
113	Дубравная ул.	дубравная-ул	\N
114	Думенко ул.	думенко-ул	\N
115	Думская ул.	думская-ул	\N
116	Думский пер.	думскии-пер	\N
117	Дунаевского ул.	дунаевского-ул	\N
118	Дунайская ул.	дунаиская-ул	\N
119	Душистая ул.	душистая-ул	\N
120	Дядьковская ул.	дядьковская-ул	\N
121	Евгении Жигуленко ул.	евгении-жигуленко-ул	\N
122	Евгения Сизоненко ул.	евгения-сизоненко-ул	\N
123	Евдокии Бершанской ул.	евдокии-бершанскои-ул	\N
124	Евдокии Сокол ул.	евдокии-сокол-ул	\N
125	Европейский ул.	европеискии-ул	\N
126	Ейская ул.	еиская-ул	\N
127	Екатериновская ул.	екатериновская-ул	\N
128	Екатеринодарская ул.	екатеринодарская-ул	\N
129	Екатерины пл.	екатерины-пл	\N
130	Екатерины Великой ул.	екатерины-великои-ул	\N
131	Елецкая ул.	елецкая-ул	\N
132	Елизаветинская ул.	елизаветинская-ул	\N
133	Елисейская ул.	елисеиская-ул	\N
134	Еловая ул.	еловая-ул	\N
135	Енисейская ул.	енисеиская-ул	\N
136	Есаульская ул.	есаульская-ул	\N
137	Есенина пер.	есенина-пер	\N
138	Есенина ул.	есенина-ул	\N
139	Ессентукская ул.	ессентукская-ул	\N
140	Железнодорожная ул.	железнодорожная-ул	\N
141	Железнодорожная (Индустриальный) ул.	железнодорожная-индустриальныи-ул	\N
142	Жемчужная ул.	жемчужная-ул	\N
143	Живило ул.	живило-ул	\N
144	Живописная ул.	живописная-ул	\N
145	Жигулёвская ул.	жигулевская-ул	\N
146	Жлобы ул.	жлобы-ул	\N
147	Жуковского ул.	жуковского-ул	\N
148	Журавлиная ул.	журавлиная-ул	\N
149	Заводская ул.	заводская-ул	\N
150	Заводская (Пашковский) ул.	заводская-пашковскии-ул	\N
151	Загорская ул.	загорская-ул	\N
152	Закатная ул.	закатная-ул	\N
153	Западная ул.	западная-ул	\N
154	Западно-Кругликовская ул.	западно-кругликовская-ул	\N
155	Западный Обход ул.	западныи-обход-ул	\N
156	Заполярная ул.	заполярная-ул	\N
157	Запорожская ул.	запорожская-ул	\N
158	Заречный пер.	заречныи-пер	\N
159	Затонная ул.	затонная-ул	\N
160	Затонный проезд	затонныи-проезд	\N
161	Захарова ул.	захарова-ул	\N
162	Защитников Отечества ул.	защитников-отечества-ул	\N
163	Званая ул.	званая-ул	\N
164	Звездная ул.	звездная-ул	\N
165	Звездный пер.	звездныи-пер	\N
166	Звездопадная ул.	звездопадная-ул	\N
167	Звенигородская ул.	звенигородская-ул	\N
168	Звенящая ул.	звенящая-ул	\N
169	Зеленоградская ул.	зеленоградская-ул	\N
170	Земляничная ул.	земляничная-ул	\N
171	Земляничная (Северный) ул.	земляничная-северныи-ул	\N
172	Зенитчиков сквер	зенитчиков-сквер	\N
173	Зины Портновой ул.	зины-портновои-ул	\N
174	Зиповская ул.	зиповская-ул	\N
175	Знаменская ул.	знаменская-ул	\N
176	Зои Космодемьянской ул.	зои-космодемьянскои-ул	\N
177	Зональная ул.	зональная-ул	\N
178	Зоотехническая ул.	зоотехническая-ул	\N
179	Ивана Кияшко пер.	ивана-кияшко-пер	\N
180	Ивана Кияшко ул.	ивана-кияшко-ул	\N
181	Ивана Кожедуба ул.	ивана-кожедуба-ул	\N
182	Ивана Рослого ул.	ивана-рослого-ул	\N
183	Ивана Сусанина ул.	ивана-сусанина-ул	\N
184	Ивановская ул.	ивановская-ул	\N
185	Ивдельская ул.	ивдельская-ул	\N
186	Игнатова ул.	игнатова-ул	\N
187	Игоря Агаркова ул.	игоря-агаркова-ул	\N
188	Измаильская ул.	измаильская-ул	\N
189	Изобильная ул.	изобильная-ул	\N
190	Изосимова ул.	изосимова-ул	\N
191	Изумрудная ул.	изумрудная-ул	\N
192	Изумрудный проезд	изумрудныи-проезд	\N
193	Ильинская ул.	ильинская-ул	\N
194	Ильский пер.	ильскии-пер	\N
195	имени Г.К. Жукова сквер	имени-гк-жукова-сквер	\N
196	имени Гатова сквер	имени-гатова-сквер	\N
197	имени Доватора ул.	имени-доватора-ул	\N
198	имени Л.Н. Толстого сквер	имени-лн-толстого-сквер	\N
199	имени Ломоносова ул.	имени-ломоносова-ул	\N
200	имени Суворова (Пашковский) ул.	имени-суворова-пашковскии-ул	\N
201	имени Ф.Э. Дзержинского сквер	имени-фэ-дзержинского-сквер	\N
202	имени Челюскина ул.	имени-челюскина-ул	\N
203	Индустриальная ул.	индустриальная-ул	\N
204	Индустриальный проезд	индустриальныи-проезд	\N
205	Инициативная ул.	инициативная-ул	\N
206	Институтская ул.	институтская-ул	\N
207	Интернациональный бульвар	интернациональныи-бульвар	\N
208	Ипподромная ул.	ипподромная-ул	\N
209	Ипподромная (СНТ Урожай) ул.	ипподромная-снт-урожаи-ул	\N
210	Ипподромный проезд	ипподромныи-проезд	\N
211	Ирклиевская ул.	ирклиевская-ул	\N
212	Иркутская ул.	иркутская-ул	\N
213	Историческая ул.	историческая-ул	\N
214	Ишунина пер.	ишунина-пер	\N
\.


--
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_notifications (id, user_id, title, message, notification_type, icon, is_read, action_url, created_at, read_at) FROM stdin;
1	2	Новый поиск от менеджера	Ваш менеджер отправил вам поиск: Поиск 2-комн в Центральный, 0-10 млн	info	fas fa-search	f	/dashboard	2025-08-14 07:59:20.881747	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, phone, telegram_id, full_name, password_hash, temp_password_hash, created_by_admin, preferred_contact, email_notifications, telegram_notifications, notify_recommendations, notify_saved_searches, notify_applications, notify_cashback, notify_marketing, profile_image, user_id, role, is_active, is_verified, verification_token, is_demo, verified, registration_source, client_notes, assigned_manager_id, client_status, preferred_district, property_type, room_count, budget_range, quiz_completed, created_at, updated_at, last_login) FROM stdin;
3	manager@inback.ru			Демо Менеджер	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB87654321	manager	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 21:05:25	2025-08-11 19:29:16.802443	2025-08-11 19:29:16.80245
4	admin@inback.ru			Администратор	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB11111111	admin	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 21:05:25	2025-08-11 19:29:16.905601	2025-08-11 19:29:16.905608
6	maria.sidorova@email.ru	+7-918-345-67-89		Мария Сидорова	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB54057265	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 21:24:54	2025-08-10 21:24:54	2025-08-11 19:29:17.112029
7	alex.kozlov@email.ru	+7-918-456-78-90		Александр Козлов	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB69534545	buyer	t	f		\N	\N	Website		\N	В работе					f	2025-08-10 21:24:55	2025-08-10 21:24:55	2025-08-11 19:29:17.214715
8	elena.smirnova@email.ru	+7-918-567-89-01		Елена Смирнова	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB78733862	buyer	t	f		\N	\N	Website		\N	Активный					f	2025-08-10 21:24:55	2025-08-10 21:24:55	2025-08-11 19:29:17.320234
9	dmitry.volkov@email.ru	+7-918-678-90-12		Дмитрий Волков	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB31150897	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 21:24:55	2025-08-10 21:24:55	2025-08-11 19:29:17.423519
10	test@inback.ru	+7900123456		Тестовый Пользователь	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB49690145	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 23:18:17	2025-08-10 23:18:17	2025-08-11 19:29:17.527442
12	email_only@inback.ru			Email Пользователь	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB71638148	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-11 15:40:09	2025-08-11 15:40:09	2025-08-11 19:29:17.636464
13	whatsapp@inback.ru	+7-918-999-88-77		WhatsApp Пользователь	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	f	f	\N	\N	\N	\N	\N	\N	CB34634650	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-11 15:40:10	2025-08-11 15:40:10	2025-08-11 19:29:17.739908
15	new.client@example.com	+7-918-123-45-67	\N	Новый Клиент	scrypt:32768:8:1$m1BwNh41dLNQDJob$5a7d95e056f43ef6f482b6678c0712f78603319025c1c0364e01ba049f3d6f7c8174e1a79d5d0519aad4d7d8f1b22c783e2c165892c7cd8c5fe95dbba0f0ca03	\N	\N	email	t	f	t	t	t	t	f	https://randomuser.me/api/portraits/men/32.jpg	CB94206088	buyer	t	f	\N	f	f	Website	\N	1	Новый	\N	\N	\N	\N	f	2025-08-12 18:43:08.064375	2025-08-12 18:43:08.064382	\N
16	working.test.client@example.com	+7-918-666-55-44	\N	Рабочий Тест Клиент	\N	\N	\N	email	t	f	t	t	t	t	f	https://randomuser.me/api/portraits/men/32.jpg	CB50027764	buyer	t	f	\N	f	f	Manager	\N	1	Новый	\N	\N	\N	\N	f	2025-08-12 18:44:41.904825	2025-08-12 18:44:41.90483	\N
17	bithomghse@mail.ru	+7-952-490-42-60	\N	Станислав hg	\N	\N	\N	email	t	f	t	t	t	t	f	https://randomuser.me/api/portraits/men/32.jpg	CB85827310	buyer	t	f	\N	f	f	Manager	\N	1	Новый	\N	\N	\N	\N	f	2025-08-12 18:52:06.547753	2025-08-12 18:52:06.547756	\N
18	test.password.client@example.com	+7-918-555-44-33	\N	Тест Пароль Клиент	scrypt:32768:8:1$8Bl7ZVq9sksCfixj$a4636e9f2913acc28a254456bd8f1e45e18aee120d1e8ef03abd08129991598410d7e323f7216cf8bdb35e2c2b8f20905aed9f66883ff03c00dbfd5943b07496	\N	\N	email	t	f	t	t	t	t	f	https://randomuser.me/api/portraits/men/32.jpg	CB11464389	buyer	t	f	\N	f	f	Manager	\N	1	Новый	\N	\N	\N	\N	f	2025-08-12 18:53:51.96034	2025-08-12 18:54:22.79387	2025-08-12 18:54:22.791864
19	new.client.final@example.com	+7-952-490-42-69	\N	Станислав Новый Клиент	scrypt:32768:8:1$1NgPsQCL2woWR2er$7420839dc57598241c819ffabfe384490a3b564a81a2dd0fa169a0ff4663bbca746106bd47a857d43239c5ced498a4ce361633fbe5f804959faae0cf11a5eba6	\N	\N	email	t	f	t	t	t	t	f	https://randomuser.me/api/portraits/men/32.jpg	CB13122017	buyer	t	f	\N	f	f	Manager	\N	1	Новый	\N	\N	\N	\N	f	2025-08-12 18:55:04.179486	2025-08-12 18:55:04.179489	\N
20	ultimaten@inback.ru	+7-952-490-82-69	730764738	Станислав Ультимейт	\N	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	ULT17550252	buyer	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-08-12 19:00:14.629974	2025-08-12 19:00:14.629974	\N
14	bithome@mail.ru	+7-952-490-82-69	730764738	Станислав Врублевский	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	both	t	t	t	\N	\N	\N	\N	\N	CB76327433	buyer	t	f		\N	\N	Website		1	Новый	Центральный	Квартира	2	4-6 млн	f	2025-08-11 15:59:11	2025-08-11 21:58:55.177116	2025-08-11 16:14:50
5	ivan.petrov@email.ru	+7-918-234-56-78		Иван Петров	scrypt:32768:8:1$JlUy6PTt3NgE7THn$04936dcc8d9df8a14b24dd8df000f62f4ea3297affdbfb8c9e027d7eae2d416f3ee1e098ee9f49fa2cb5c8d6135428334322de65d765627a8d63b3b3efc22f4f	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB39259319	buyer	f	f		\N	\N	Website		\N	Активный					f	2025-08-10 21:24:54	2025-08-14 08:43:56.721998	2025-08-14 08:43:56.720094
2	demo@inback.ru			Демо Покупатель	scrypt:32768:8:1$yBxWMnshg9JxxFuY$fd92a8332fbe40fafe78992b52903a725f00219c39cf1efb970fe2ef3b936c2cb8cc435e343d3dca6d4aedeadcc39cea34dde806541abd9df8ecad75bd66eb2e	\N	\N	email	t	f	\N	\N	\N	\N	\N	\N	CB12345678	buyer	t	f		\N	\N	Website		\N	Новый					f	2025-08-10 21:05:25	2025-08-15 13:48:14.612473	2025-08-15 13:48:14.610213
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


--
-- Name: applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.applications_id_seq', 5, true);


--
-- Name: blog_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_articles_id_seq', 5, true);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 21, true);


--
-- Name: blog_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_comments_id_seq', 1, false);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 15, true);


--
-- Name: blog_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.blog_tags_id_seq', 1, false);


--
-- Name: callback_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.callback_requests_id_seq', 5, true);


--
-- Name: cashback_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cashback_applications_id_seq', 1, false);


--
-- Name: cashback_payouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cashback_payouts_id_seq', 1, false);


--
-- Name: cashback_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cashback_records_id_seq', 1, false);


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cities_id_seq', 1, false);


--
-- Name: client_property_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.client_property_recommendations_id_seq', 1, false);


--
-- Name: collection_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.collection_properties_id_seq', 1, false);


--
-- Name: collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.collections_id_seq', 1, false);


--
-- Name: developer_appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.developer_appointments_id_seq', 1, false);


--
-- Name: developers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.developers_id_seq', 12, true);


--
-- Name: districts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.districts_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: favorite_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.favorite_properties_id_seq', 20, true);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, false);


--
-- Name: manager_saved_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.manager_saved_searches_id_seq', 1, true);


--
-- Name: managers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.managers_id_seq', 1, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: recommendation_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recommendation_categories_id_seq', 7, true);


--
-- Name: recommendation_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recommendation_templates_id_seq', 1, false);


--
-- Name: recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.recommendations_id_seq', 24, true);


--
-- Name: residential_complexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.residential_complexes_id_seq', 8, true);


--
-- Name: room_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.room_types_id_seq', 1, false);


--
-- Name: saved_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.saved_searches_id_seq', 30, true);


--
-- Name: search_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.search_categories_id_seq', 1, false);


--
-- Name: sent_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sent_searches_id_seq', 1, true);


--
-- Name: streets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.streets_id_seq', 214, true);


--
-- Name: user_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_notifications_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 20, true);


--
-- Name: admins admins_admin_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_admin_id_key UNIQUE (admin_id);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: blog_article_tags blog_article_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_pkey PRIMARY KEY (article_id, tag_id);


--
-- Name: blog_articles blog_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_articles
    ADD CONSTRAINT blog_articles_pkey PRIMARY KEY (id);


--
-- Name: blog_articles blog_articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_articles
    ADD CONSTRAINT blog_articles_slug_key UNIQUE (slug);


--
-- Name: blog_categories blog_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_name_key UNIQUE (name);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_categories blog_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_slug_key UNIQUE (slug);


--
-- Name: blog_comments blog_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_key UNIQUE (slug);


--
-- Name: blog_tags blog_tags_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_name_key UNIQUE (name);


--
-- Name: blog_tags blog_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_pkey PRIMARY KEY (id);


--
-- Name: blog_tags blog_tags_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_tags
    ADD CONSTRAINT blog_tags_slug_key UNIQUE (slug);


--
-- Name: callback_requests callback_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.callback_requests
    ADD CONSTRAINT callback_requests_pkey PRIMARY KEY (id);


--
-- Name: cashback_applications cashback_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_applications
    ADD CONSTRAINT cashback_applications_pkey PRIMARY KEY (id);


--
-- Name: cashback_payouts cashback_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_payouts
    ADD CONSTRAINT cashback_payouts_pkey PRIMARY KEY (id);


--
-- Name: cashback_records cashback_records_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_records
    ADD CONSTRAINT cashback_records_pkey PRIMARY KEY (id);


--
-- Name: cities cities_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_name_key UNIQUE (name);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: cities cities_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_slug_key UNIQUE (slug);


--
-- Name: client_property_recommendations client_property_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_property_recommendations
    ADD CONSTRAINT client_property_recommendations_pkey PRIMARY KEY (id);


--
-- Name: collection_properties collection_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collection_properties
    ADD CONSTRAINT collection_properties_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: developer_appointments developer_appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developer_appointments
    ADD CONSTRAINT developer_appointments_pkey PRIMARY KEY (id);


--
-- Name: developers developers_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_name_key UNIQUE (name);


--
-- Name: developers developers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_pkey PRIMARY KEY (id);


--
-- Name: developers developers_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_slug_key UNIQUE (slug);


--
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- Name: districts districts_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_slug_key UNIQUE (slug);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: favorite_properties favorite_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorite_properties
    ADD CONSTRAINT favorite_properties_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: manager_saved_searches manager_saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.manager_saved_searches
    ADD CONSTRAINT manager_saved_searches_pkey PRIMARY KEY (id);


--
-- Name: managers managers_manager_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_manager_id_key UNIQUE (manager_id);


--
-- Name: managers managers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: recommendation_categories recommendation_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_categories
    ADD CONSTRAINT recommendation_categories_pkey PRIMARY KEY (id);


--
-- Name: recommendation_templates recommendation_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_templates
    ADD CONSTRAINT recommendation_templates_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: residential_complexes residential_complexes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.residential_complexes
    ADD CONSTRAINT residential_complexes_pkey PRIMARY KEY (id);


--
-- Name: residential_complexes residential_complexes_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.residential_complexes
    ADD CONSTRAINT residential_complexes_slug_key UNIQUE (slug);


--
-- Name: room_types room_types_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.room_types
    ADD CONSTRAINT room_types_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: search_categories search_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.search_categories
    ADD CONSTRAINT search_categories_pkey PRIMARY KEY (id);


--
-- Name: sent_searches sent_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sent_searches
    ADD CONSTRAINT sent_searches_pkey PRIMARY KEY (id);


--
-- Name: streets streets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT streets_pkey PRIMARY KEY (id);


--
-- Name: streets streets_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT streets_slug_key UNIQUE (slug);


--
-- Name: favorites unique_user_property; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT unique_user_property UNIQUE (user_id, property_id);


--
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_id_key UNIQUE (user_id);


--
-- Name: ix_admins_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_admins_email ON public.admins USING btree (email);


--
-- Name: ix_managers_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_managers_email ON public.managers USING btree (email);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: applications applications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blog_article_tags blog_article_tags_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.blog_articles(id);


--
-- Name: blog_article_tags blog_article_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.blog_tags(id);


--
-- Name: blog_articles blog_articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_articles
    ADD CONSTRAINT blog_articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.managers(id);


--
-- Name: blog_articles blog_articles_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_articles
    ADD CONSTRAINT blog_articles_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.blog_categories(id);


--
-- Name: blog_comments blog_comments_article_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_article_id_fkey FOREIGN KEY (article_id) REFERENCES public.blog_articles(id);


--
-- Name: blog_comments blog_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.blog_comments(id);


--
-- Name: blog_comments blog_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_comments
    ADD CONSTRAINT blog_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blog_posts blog_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.admins(id);


--
-- Name: callback_requests callback_requests_assigned_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.callback_requests
    ADD CONSTRAINT callback_requests_assigned_manager_id_fkey FOREIGN KEY (assigned_manager_id) REFERENCES public.managers(id);


--
-- Name: cashback_applications cashback_applications_approved_by_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_applications
    ADD CONSTRAINT cashback_applications_approved_by_manager_id_fkey FOREIGN KEY (approved_by_manager_id) REFERENCES public.managers(id);


--
-- Name: cashback_applications cashback_applications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_applications
    ADD CONSTRAINT cashback_applications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cashback_payouts cashback_payouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_payouts
    ADD CONSTRAINT cashback_payouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cashback_records cashback_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cashback_records
    ADD CONSTRAINT cashback_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: client_property_recommendations client_property_recommendations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_property_recommendations
    ADD CONSTRAINT client_property_recommendations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: client_property_recommendations client_property_recommendations_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_property_recommendations
    ADD CONSTRAINT client_property_recommendations_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: client_property_recommendations client_property_recommendations_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.client_property_recommendations
    ADD CONSTRAINT client_property_recommendations_search_id_fkey FOREIGN KEY (search_id) REFERENCES public.saved_searches(id);


--
-- Name: collection_properties collection_properties_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collection_properties
    ADD CONSTRAINT collection_properties_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id);


--
-- Name: collections collections_assigned_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_assigned_to_user_id_fkey FOREIGN KEY (assigned_to_user_id) REFERENCES public.users(id);


--
-- Name: collections collections_created_by_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_created_by_manager_id_fkey FOREIGN KEY (created_by_manager_id) REFERENCES public.managers(id);


--
-- Name: developer_appointments developer_appointments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developer_appointments
    ADD CONSTRAINT developer_appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: documents documents_reviewed_by_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_reviewed_by_manager_id_fkey FOREIGN KEY (reviewed_by_manager_id) REFERENCES public.managers(id);


--
-- Name: documents documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: favorite_properties favorite_properties_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorite_properties
    ADD CONSTRAINT favorite_properties_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: manager_saved_searches manager_saved_searches_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.manager_saved_searches
    ADD CONSTRAINT manager_saved_searches_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.managers(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recommendation_categories recommendation_categories_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_categories
    ADD CONSTRAINT recommendation_categories_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: recommendation_categories recommendation_categories_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_categories
    ADD CONSTRAINT recommendation_categories_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.managers(id);


--
-- Name: recommendation_templates recommendation_templates_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendation_templates
    ADD CONSTRAINT recommendation_templates_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.managers(id);


--
-- Name: recommendations recommendations_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.recommendation_categories(id);


--
-- Name: recommendations recommendations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: recommendations recommendations_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.managers(id);


--
-- Name: residential_complexes residential_complexes_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.residential_complexes
    ADD CONSTRAINT residential_complexes_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: saved_searches saved_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sent_searches sent_searches_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sent_searches
    ADD CONSTRAINT sent_searches_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: sent_searches sent_searches_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sent_searches
    ADD CONSTRAINT sent_searches_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.managers(id);


--
-- Name: sent_searches sent_searches_manager_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sent_searches
    ADD CONSTRAINT sent_searches_manager_search_id_fkey FOREIGN KEY (manager_search_id) REFERENCES public.manager_saved_searches(id);


--
-- Name: streets streets_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT streets_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: user_notifications user_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_assigned_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_assigned_manager_id_fkey FOREIGN KEY (assigned_manager_id) REFERENCES public.managers(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

